﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine
{
    public class FPSViwer
    {

        DateTime starttime;
        public void BlockStart()
        {
            starttime = DateTime.Now;
         
        }

        long tick = 1;
        public void BlockEnd()
        {
            DateTime endtime = DateTime.Now;
            long ticks = (endtime - starttime).Ticks;

            if (ticks != 0)
            {
                tick = ticks;            
            }
                
        }




        public int FPS
        {
            get { return (int)(10000000 / tick); }
        }
        public long Delay
        {
            get { return tick; }
        }
        public float Rate
        {
            get { return (10000f / tick); }
        }

    }
}
