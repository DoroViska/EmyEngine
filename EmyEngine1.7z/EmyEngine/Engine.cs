﻿using System;
using System.IO;
using System.Diagnostics;
using EmyEngine.SDL2;
using EmyEngine.ResourceManagment;
using EmyEngine.Models3D;
using EmyEngine.GUI;

namespace EmyEngine
{
    public class GameEngine
    {
        private static string pathE;
        public static string EnginePath { get { return pathE; } }



        static Resources _CurrentResources = null;
        public static Resources CurrentResources
        {
            get
            {
                if (_CurrentResources == null)
                    throw new PropetryNotInitializeException(nameof(CurrentResources));
                return _CurrentResources;
            }
            set
            {
                _CurrentResources = value;
            }
        }


        static Model3DManager _CurrentModels = null;
        public static Model3DManager CurrentModels
        {
            get
            {
                if (_CurrentModels == null)
                    throw new PropetryNotInitializeException(nameof(_CurrentModels));
                return _CurrentModels;
            }
            set
            {
                _CurrentModels = value;
            }
        }
        static Font _CurrentFont = null;

        public static Font CurrentFont
        {
            get
            {
                if (_CurrentFont == null)
                    throw new PropetryNotInitializeException(nameof(_CurrentFont));
                return _CurrentFont;
            }
            set
            {
                _CurrentFont = value;
            }
        }






        public static void Initialize()
        {

            Environment.SetEnvironmentVariable("Path", Environment.GetEnvironmentVariable("Path") + ";" + new System.IO.DirectoryInfo("./wnidows_x86_64.dlls").FullName);
            pathE = new FileInfo(Process.GetCurrentProcess().MainModule.FileName).Directory.FullName;



            SDL.SDL_GL_SetAttribute(SDL_GLattr.SDL_GL_DOUBLEBUFFER, 1);
            SDL.SDL_GL_SetAttribute(SDL_GLattr.SDL_GL_RED_SIZE, 5);
            SDL.SDL_GL_SetAttribute(SDL_GLattr.SDL_GL_GREEN_SIZE, 6);
            SDL.SDL_GL_SetAttribute(SDL_GLattr.SDL_GL_BLUE_SIZE, 5);
            
            if (SDL.SDL_Init(SDL.SDL_INIT_VIDEO) < 0)
            { /* Initialize SDL's Video subsystem */

                throw new Exception("Не удалось инициализировать SDL's Видео Систему");
            }
        }










        public static void Quit()
        {
            SDL.SDL_Quit();
        }

    }
}
