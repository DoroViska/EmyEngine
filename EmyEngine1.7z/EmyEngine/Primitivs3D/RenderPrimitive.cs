﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using EmyEngine;
using EmyEngine.SDL2;
using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;
namespace EmyEngine.Primitivs3D
{
    public abstract class RenderPrimitive
    {
        int CallList;
        public RenderPrimitive()
        {
            CallList = GL.GenLists(1);
            GL.NewList(CallList, ListMode.Compile);
            this.OnRender();
            GL.EndList();
        }


        public void Draw()
        {
            GL.CallList(CallList);
        }

        public abstract void OnRender();
    }
}
