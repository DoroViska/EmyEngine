﻿using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#pragma warning disable
namespace EmyEngine.Primitivs3D
{
    public class CylinderPrimitive : RenderPrimitive
    {
        public override void OnRender()
        {
            GL.PushMatrix();      
            {
                GL.Rotate(90f, 1f, 0f, 0f);
                drawCylinder(1f, 1f, 0f);
            }
            GL.PopMatrix();
        }

        static void drawCylinder(float l, float r, float zoffset)
        {

           
            int num1 = 24;
            l *= 0.5f;
            float num2 = 6.283185f / (float)num1;
            float num3 = (float)Math.Sin((double)num2);
            float num4 = (float)Math.Cos((double)num2);
            float num5 = 1f;
            float num6 = 0.0f;
            GL.Begin(PrimitiveType.TriangleStrip); 
            for (int index = 0; index <= num1; ++index)
            {
                GL.Normal3(num5, num6, 0.0f);
                GL.Vertex3(num5 * r, num6 * r, l + zoffset);
                GL.Normal3(num5, num6, 0.0f);
                GL.Vertex3(num5 * r, num6 * r, -l + zoffset);
                float num7 = (float)((double)num4 * (double)num5 - (double)num3 * (double)num6);
                num6 = (float)((double)num3 * (double)num5 + (double)num4 * (double)num6);
                num5 = num7;
            }
            GL.End();
         //   GL.ShadeModel((ShadingModel)7424);
            float num8 = 1f;
            float num9 = 0.0f;
            GL.Begin((BeginMode)6);
            GL.Normal3(0.0f, 0.0f, 1f);
            GL.Vertex3(0.0f, 0.0f, l + zoffset);
            for (int index = 0; index <= num1; ++index)
            {
             
                GL.Normal3(0.0f, 0.0f, 1f);
                GL.Vertex3(num8 * r, num9 * r, l + zoffset);
             
                float num7 = (float)((double)num4 * (double)num8 - (double)num3 * (double)num9);
                num9 = (float)((double)num3 * (double)num8 + (double)num4 * (double)num9);
                num8 = num7;
            }
            GL.End();
            float num10 = 1f;
            float num11 = 0.0f;
            GL.Begin((BeginMode)6);
            GL.Normal3(0.0f, 0.0f, -1f);
            GL.Vertex3(0.0f, 0.0f, -l + zoffset);
            for (int index = 0; index <= num1; ++index)
            {

                GL.Normal3(0.0f, 0.0f, -1f);
                GL.Vertex3(num10 * r, num11 * r, -l + zoffset);

                float num7 = (float)((double)num4 * (double)num10 + (double)num3 * (double)num11);
                num11 = (float)(-(double)num3 * (double)num10 + (double)num4 * (double)num11);
                num10 = num7;
            }
            GL.End();

          // GL.Rotate(90f, 1f, 1f, 1f);
        }
    }
}
