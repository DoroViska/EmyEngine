﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;
using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;

namespace EmyEngine.Primitivs3D
{
    public class SpherePrimitive : RenderPrimitive
    {
        public override void OnRender()
        {
            GL.PushMatrix();
            drawSphere(0,10,10);
            GL.PopMatrix();
      
        }
        public static void drawSphere(double r, int lats, int longs)
        {
            int i, j;
            for (i = 0; i <= lats; i++)
            {
                double lat0 = Math.PI * (-0.5 + (double)(i - 1) / lats);
                double z0 = Math.Sin(lat0);
                double zr0 = Math.Cos(lat0);

                double lat1 = Math.PI * (-0.5 + (double)i / lats);
                double z1 = Math.Sin(lat1);
                double zr1 = Math.Cos(lat1);

                GL.Begin(PrimitiveType.QuadStrip);
                for (j = 0; j <= longs; j++)
                {
                    double lng = 2 * Math.PI * (double)(j - 1) / longs;
                    double x = Math.Cos(lng);
                    double y = Math.Sin(lng);

                    GL.Normal3(x * zr0, y * zr0, z0);
                    GL.Vertex3(x * zr0, y * zr0, z0);
                    GL.Normal3(x * zr1, y * zr1, z1);
                    GL.Vertex3(x * zr1, y * zr1, z1);
                }
                GL.End();
            
            }
        }
    }
}
