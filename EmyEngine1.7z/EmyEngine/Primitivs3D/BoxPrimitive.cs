﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;

using OpenTK.Graphics.OpenGL;

namespace EmyEngine.Primitivs3D
{
    public class BoxPrimitive : RenderPrimitive
    {
        public override void OnRender()
        {
            GL.PushMatrix();
            float x = 1f * 0.5f;
            float y = 1f * 0.5f;
            float z = 1f * 0.5f;
            GL.Begin(PrimitiveType.TriangleStrip);
            GL.Normal3(-1f, 0.0f, 0.0f);
            GL.Vertex3(-x, -y, -z);
            GL.Vertex3(-x, -y, z);
            GL.Vertex3(-x, y, -z);
            GL.Vertex3(-x, y, z);
            GL.Normal3(0.0f, 1f, 0.0f);
            GL.Vertex3(x, y, -z);
            GL.Vertex3(x, y, z);
            GL.Normal3(1f, 0.0f, 0.0f);
            GL.Vertex3(x, -y, -z);
            GL.Vertex3(x, -y, z);
            GL.Normal3(0.0f, -1f, 0.0f);
            GL.Vertex3(-x, -y, -z);
            GL.Vertex3(-x, -y, z);
            GL.End();
            GL.Begin(PrimitiveType.TriangleFan);
            GL.Normal3(0.0f, 0.0f, 1f);
            GL.Vertex3(-x, -y, z);
            GL.Vertex3(x, -y, z);
            GL.Vertex3(x, y, z);
            GL.Vertex3(-x, y, z);
            GL.End();
            GL.Begin(PrimitiveType.TriangleFan);
            GL.Normal3(0.0f, 0.0f, -1f);
            GL.Vertex3(-x, -y, -z);
            GL.Vertex3(-x, y, -z);
            GL.Vertex3(x, y, -z);
            GL.Vertex3(x, -y, -z);
            GL.End();
            GL.PopMatrix();
        }
    }
}
