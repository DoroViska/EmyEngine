﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;
using OpenTK.Graphics.OpenGL;
namespace EmyEngine.Primitivs3D
{
    public class GridPrimitive : RenderPrimitive
    {
     

        public override void OnRender()
        {

            GL.Color3(1.0f, 1.0f, 1.0f);
            GL.PushMatrix();
            {

                GL.Begin(PrimitiveType.Lines);
                for (float x = -50.0f; x < 50; x++)
                {
                    for (float y = -50.0f; y < 50; y++)
                    {
                        GL.Vertex3(x, 0, y);
                        GL.Vertex3(x, 0, y + 1);

                        GL.Vertex3(x, 0, y);
                        GL.Vertex3(x + 1, 0, y);
                    }
                }

                GL.End();
            }

            GL.PopMatrix();
        }
    }
}
