﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
namespace EmyEngine
{
    public class ThreadFPSViwer : IDisposable
    {

        public event Action<ThreadFPSViwer> FPSChanged;

        Timer tm = null;
        public ThreadFPSViwer()
        {
            tm = new Timer();
            tm.Interval = 999;
            tm.Elapsed += Tm_Elapsed;
            tm.Start();

        }
        int valuer = 0;
        object objlook = new object();
        private void Tm_Elapsed(object sender, ElapsedEventArgs e)
        {
            lock(objlook)
            {
                FPS = valuer;
                valuer = 0;
            }
            if (FPSChanged != null)
                FPSChanged(this);


        }

        public void Impulse()
        {
            lock (objlook)
            {
                valuer++;
            }
          
        }

        public void Dispose()
        {
            tm.Dispose();
            GC.SuppressFinalize(tm);
            GC.SuppressFinalize(this);

        }

        public int FPS { private set; get; }


    }
}
