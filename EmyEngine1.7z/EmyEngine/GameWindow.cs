﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine.SDL2;
using static EmyEngine.SDL2.SDL;
using static EmyEngine.SDL2.SDL_WindowFlags;
using OpenTK.Graphics;
using OpenTK;

namespace EmyEngine
{
    public delegate void Render(IGLView sender);
    public delegate void Frameing(IGLView sender);
    public delegate void Loaded(IGLView sender);
    public delegate void Resized(IGLView sender);
    public delegate void KeyPresed(IGLView sender,int keycode);
     

    public unsafe class GameWindow : IDisposable, IGLView
    {
        public event Render Render;
        public void OnRender(IGLView sender) { if (Render != null) Render(sender); }

        public event Loaded Loaded;
        public void OnLoaded(IGLView sender) { if (Loaded != null) Loaded(sender); }
        public event Resized Resized;
        public void OnResized(IGLView sender) { if (Resized != null) Resized(sender); }
        public event KeyPresed KeyPresed;
        public void OnKeyPresedd(IGLView sender, int keycode) { if (KeyPresed != null) KeyPresed(sender, keycode); }


        ~GameWindow()
        {
            Dispose();
        }
        public SDL_GLContext GLContext { set; get; }
        public SDL_Window* WindowPtr { set; get; }
        public string Title { set; get; }

        public int Width
        {
            set
            {
                SDL.SDL_SetWindowSize(this.WindowPtr,value,this.Height);
            } 

            get
            {
                int Ws, Hs;
                SDL.SDL_GetWindowSize(this.WindowPtr, &Ws, &Hs);
                return Ws;
            }
        }
        public int Height
        {
            set
            {
                SDL.SDL_SetWindowSize(this.WindowPtr, this.Width, value);
            }

            get
            {
                int Ws, Hs;
                SDL.SDL_GetWindowSize(this.WindowPtr, &Ws, &Hs);
                return Hs;
            }
        }

        public GameWindow(string title)
        {
            Title = title;
            SDL_DisplayMode current;
            SDL.SDL_GetCurrentDisplayMode(0, &current);
            CreateWindow(current.w - 100, current.h - 100);
        }
        public GameWindow(string title,int w,int h)
        {
            Title = title;
            CreateWindow(w,h);
        }

 
        private void CreateWindow(int w,int h)
        {
            SDL_DisplayMode n;
            SDL_GetCurrentDisplayMode(0,&n);
            WindowPtr = SDL.SDL_CreateWindow(Title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h,
            SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL |SDL_WINDOW_RESIZABLE );
            GLContext = SDL_GL_CreateContext(WindowPtr);
            if (WindowPtr == null)
            {
                throw new Exception("Не удалось создать Window!");
            }
            GraphicsContext opentk_context = new GraphicsContext(new ContextHandle( new IntPtr(GLContext.ptr)), (name) => {/*Console.WriteLine("{get_address}: " + name); */return SDL_GL_GetProcAddress(name); },() => { return new ContextHandle(SDL_GL_GetCurrentContext()); });
            if (opentk_context.IsDisposed == true)
            {
                throw new Exception("Не удалось создать GraphicsContext!");
            }

            //  if (opentk_context. = true)
            //   {
            ///        throw new Exception("Не удалось создать OpenGL Context!");
            //      }

        }


        public void FullScrinEnabale()
        {
            SDL_DisplayMode current;
            SDL_GetCurrentDisplayMode(0, &current);
            SDL_SetWindowSize(WindowPtr, current.w, current.h);
            SDL.SDL_SetWindowFullscreen(WindowPtr, (uint)SDL_bool.SDL_TRUE);
        }
        public void FullScrinDisable()
        {
            SDL.SDL_SetWindowSize(WindowPtr, 700, 500);
            SDL.SDL_SetWindowFullscreen(WindowPtr, (uint)SDL_bool.SDL_FALSE);
        }

        public bool IsRunning { set; get; }
        public void Run(bool fullsc = true)
        {
            
            OnLoaded(this);
            if (fullsc)
            {
                SDL_DisplayMode current;
                SDL.SDL_GetCurrentDisplayMode(0, &current);
                //Interop.SDL_SetWindowSize(WindowPtr, current.w, current.h);
                SDL.SDL_SetWindowSize(WindowPtr, 900, 600);
                SDL.SDL_SetWindowFullscreen(WindowPtr, (uint)SDL_bool.SDL_TRUE);
           
            }
            OnResized(this);
            IsRunning = true;
            while (IsRunning)
            {
                SDL_Event eventt;
                while (SDL.SDL_PollEvent(&eventt))
                {
                    switch (eventt.type)
                    { // смотрим:
                        case (uint)SDL_EventType.SDL_QUIT: // если произошло событие закрытия окна, то завершаем работу программы
                            this.Close();
                            return;

                        case (uint)SDL_EventType.SDL_WINDOWEVENT: // если произошло событие закрытия окна, то завершаем работу программы
                            if (eventt.window.eventt == SDL_WindowEventID.SDL_WINDOWEVENT_RESIZED)
                                //Console.WriteLine("[window resized]");
                                OnResized(this);
                            break;

                        case (uint)SDL_EventType.SDL_KEYDOWN: // если произошло событие закрытия окна, то завершаем работу программы
                            OnKeyPresedd(this, eventt.key.keysym.sym);
                            //Console.WriteLine("[key press] " + eventt.key.keysym.sym);
                            //if (Key.SDLK_ESCAPE == eventt.key.keysym.sym)
                            //{
                            //    this.Close();
                            //}
                            if (Key.SDLK_p == eventt.key.keysym.sym)
                            { 
                                SDL_DisplayMode current;
                                SDL.SDL_GetCurrentDisplayMode(0, &current);
                                SDL.SDL_SetWindowSize(WindowPtr, current.w, current.h);
                                SDL.SDL_SetWindowFullscreen(WindowPtr, (uint)SDL_bool.SDL_TRUE);
                            }
                            if (Key.SDLK_o == eventt.key.keysym.sym)
                            {
                                SDL.SDL_SetWindowSize(WindowPtr, 700, 500);
                                SDL.SDL_SetWindowFullscreen(WindowPtr, (uint)SDL_bool.SDL_FALSE);
                            }

                            break;
                    }
                }
                OnRender(this);
                //OnFrameing(this);
            }
        
        }
       

        public void Swap()
        {
            SDL.SDL_GL_SwapWindow(WindowPtr);
        }
        public void Close()
        {
            IsRunning = false;
            SDL.SDL_GL_DeleteContext(GLContext);
        }

        public void Dispose()
        {
            Close();
            GC.SuppressFinalize(this);
        }

        public void* TryToGetWindowPtr()
        {
            return this.WindowPtr;
        }

        public int X { get
            {
                int x;
                int y;
                SDL_GetWindowPosition(WindowPtr,&x,&y);
                return x;
            } }
        public int Y
        {
            get
            {
                int x;
                int y;
                SDL_GetWindowPosition(WindowPtr, &x, &y);
                return y;
            }
        }

    }
}
