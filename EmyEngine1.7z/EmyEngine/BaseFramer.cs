﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine
{
    public class TimedFramer
    {
        float friction;
        public TimedFramer(IGLView framer, float friction = F60)
        {
            this.friction = friction;
            framer.Render += Framer_Render;

        }




        private void Framer_Render(IGLView sender)
        {
            RenderTimes.BlockStart();
            DateTime st = DateTime.Now;
            this.Render(sender);
            DateTime end = DateTime.Now;
            RenderTimes.BlockEnd();

            FrameTimes.BlockStart();
            int col_woInterac = (int)(((float)((end - st).Milliseconds)) / friction);
            if (col_woInterac == 0) col_woInterac = 1;
            FrameCmds = col_woInterac;
            while (col_woInterac != 0)
            {
                col_woInterac--;
                this.Framing(sender);
            }
            FrameTimes.BlockEnd();
        }

        public int FrameCmds { set; get; }
        public float PhysDelays { private set; get; } = 0.01f;

        public FPSViwer FrameTimes { set; get; } = new FPSViwer();
        public FPSViwer RenderTimes { set; get; } = new FPSViwer();


        public const float F60 = 16.666666666666666666666666666666666666666666666666666666666666666666666666666666666666666f;
        public const float F30 = 33.333333333333333333333333333333333333333333333333333333333333333333333333333333333333333f;
        public const float F120 = 8.333333333333333333333333333333333333333333333333333333333333333333333333333333333333333f;

        public event Render Render;
        public event Frameing Framing;
    }
}
