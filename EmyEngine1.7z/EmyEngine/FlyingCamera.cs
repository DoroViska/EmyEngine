﻿using EmyEngine.SDL2;
using OpenTK;
using OpenTK.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
namespace EmyEngine
{
    public unsafe class FlyingCamera
    {
        public FlyingCamera()
        {
            AngleX = 0f;
            AngleY = 0f;
            PushAngle(0, 0);
        }
        public float AngleX { set; get; }
        public float AngleY { set; get; }

        public JVector DirectionZero = JVector.Zero;
        public JVector Direction  = JVector.Zero;
        public JVector HeadPosition { set; get; } = new JVector(0f,5f,0f);
        public JVector UpVector { set; get; } = new JVector(0f,1f,0f);

        public void PushAngle(float x,float y)
        {
          
              AngleX += x;
           // if (AngleX > 359) { AngleX = 0; }
            AngleY += y;
          //  if (AngleY > 359) { AngleY = 0; }

            Direction.X = (float)Math.Cos((AngleX));
            Direction.Y = (float)Math.Tan((AngleY));
            Direction.Z = (float)Math.Sin((AngleX));
            DirectionZero = Direction;

        }

        public int oldX { set; get; }
        public int oldY { set; get; }

        public bool MyConvision { set; get; } = true;
        public void MultMatrix(GameWindow wnd, bool use_mouse)
        {


            if (MyConvision) {

                byte* KeyBoardState = SDL.SDL_GetKeyboardState(null);

                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_W] != 0)
                {
                    HeadPosition += (new JVector(
                       (float)Math.Cos(this.AngleX) * 1
                       ,
                       0,
                       (float)Math.Sin(this.AngleX) * 1
                       ));
                }



                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_S] != 0)
                {
                    HeadPosition += (new JVector(
                      (float)Math.Cos(this.AngleX) * -1
                      ,
                      0,
                      (float)Math.Sin(this.AngleX) * -1
                      ));
                }


                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_A] != 0)
                {
                    HeadPosition += (new JVector(
                    ((float)Math.Cos(this.AngleX + (float)Math.PI / 2)) * -1
                    ,
                    0,
                     ((float)Math.Sin(this.AngleX + (float)Math.PI / 2)) * -1
                    ));
                }




                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_D] != 0)
                {

                    HeadPosition += (new JVector(
                        ((float)Math.Cos(this.AngleX + (float)Math.PI / 2)) * 1
                        ,
                        0,
                         ((float)Math.Sin(this.AngleX + (float)Math.PI / 2)) * 1
                        ));


                }


                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_SPACE] != 0)
                {

                    HeadPosition += (new JVector(
                     0
                        ,
                        0.4f,
                       0
                        ));


                }


                if (KeyBoardState[(uint)EmyEngine.SDL2.SDL_Scancode.SDL_SCANCODE_LCTRL] != 0)
                {

                    HeadPosition += (new JVector(
                       0
                        ,
                       -0.4f,
                       0
                        ));


                }

            }




            if (use_mouse)
            {
                int xm = 0;
                int ym = 0;
                SDL.SDL_GetMouseState(&xm, &ym);

                this.PushAngle(((float)this.oldX - (float)xm) / -400, ((float)this.oldY - (float)ym) / 400);
                SDL.SDL_WarpMouseInWindow(wnd.WindowPtr, (ushort)(wnd.Width / 2), (ushort)(wnd.Height / 2));

                this.oldX = wnd.Width / 2;
                this.oldY = wnd.Height / 2;


                Direction += HeadPosition;
            }

         

              Transformator.LookAt (HeadPosition.X, HeadPosition.Y, HeadPosition.Z, Direction.X, Direction.Y, Direction.Z, UpVector.X, UpVector.Y, UpVector.Z);
        }
        public void ResetPosition(IGLView wnd,bool rester)
        {
            SDL.SDL_WarpMouseInWindow((SDL_Window*)wnd.TryToGetWindowPtr(), (ushort)(wnd.Width / 2), (ushort)(wnd.Height / 2));
        }



    }
}
