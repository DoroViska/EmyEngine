﻿using System.IO;

namespace EmyEngine.ResourceManagment
{
    public interface IResource
    {
        byte[] Data { get; }
        string Path { get; }
        Stream GetStream();
    }
}