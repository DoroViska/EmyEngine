﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.ResourceManagment
{
    public abstract class Resources
    {
        public List<IResource> Tree { protected set; get; } = new List<IResource>();

        public const string PathSeparator = "/";

        public static string PathFormat(params string[] r)
        {
            return string.Join(PathSeparator, r);
        }

        public IResource GetResource(string path)
        {
            foreach (IResource _r in Tree)
            {
                if (path == _r.Path)
                {
                    return _r;
                }

            }
            throw new ResourceNotFoundException(path);
        }
        public IResource[] GetResources() { return Tree.ToArray(); }
        public IResource[] GetResources(string path)
        {
            string handle = path;
            if (handle.Remove(0, handle.Length - 1) != "/")
            {
                handle += "/";
            }

            List<IResource> g = new List<IResource>();
            foreach (IResource rs in Tree)
            {
                try
                {
                    if (rs.Path.Length < handle.Length) continue;
                    if (rs.Path.Remove(handle.Length, rs.Path.Length - handle.Length) == handle)
                    {
                        //Console.WriteLine("[res]: " + rs.FullName);
                        g.Add(rs);
                    }


                }
                catch (Exception ex) { ex.ToString(); }

            }
            return g.ToArray();

        }


    }
}
