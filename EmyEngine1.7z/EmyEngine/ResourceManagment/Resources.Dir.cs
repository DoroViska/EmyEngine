﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace EmyEngine.ResourceManagment
{
    public class ResourcesDir : Resources
    {

        public void Open(string dir)
        {

            PushDir(dir,"");

        }
        public void ReadAll()
        {

            DirectoryInfo dr = new DirectoryInfo("./");
            foreach (DirectoryInfo nfpo in dr.GetDirectories())
            {
                try {
                    if (nfpo.Name.IndexOf("res") == 0)
                    {
                        PushDir(nfpo.FullName, "");
                      
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

               
            }
        }



        private void PushDir(string dir_path, string handle )
        {
            DirectoryInfo _dir_path = new DirectoryInfo(dir_path);
            if (!_dir_path.Exists) throw new Exception("Не найден игровой ресурс: " + dir_path);
            foreach (FileInfo f in _dir_path.GetFiles())
            {
                Console.WriteLine("[ресурсе]  " + handle + f.Name);
                FileStream strea = new FileStream(f.FullName,FileMode.Open,FileAccess.Read);
                byte[] rw = new byte[strea.Length];
                strea.Read(rw,0, rw.Length);
                strea.Close();
                
                Resource nr = new Resource(handle + f.Name,rw);
                this.Tree.Add(nr);
            }

            foreach (DirectoryInfo d in _dir_path.GetDirectories())
            {

                this.PushDir(d.FullName,handle + d.Name + "/");
            }

        }



    }
}
