﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace EmyEngine.ResourceManagment
{
    public class Resource : IResource
    {
        public Resource(string Path, byte[] data)
        {
            this.Data = data;
            this.Path = Path;
        }


        public Stream GetStream()
        {
            return new MemoryStream(Data);
        }

        public string Path { private set; get; }
        public string Name
        {
            get
            { 
                return Path.Remove(0, Path.LastIndexOf('/') + 1);
            }
        }


        public byte[] Data  { private set; get; }


    }
}
