﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.LinearMath;
using Jitter.Collision.Shapes;

using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;
using OpenTK;
#pragma warning disable
namespace EmyEngine
{
    /// <summary>
    /// Представляет несущий контроллер матриц.
    /// </summary>
    public static unsafe class Transformator
    {


        public static void Perspective(float fovy, float aspect, float zNear = 0.001f, float zFar = 1000f)
        {
            Matrix4 cc;
            cc = Matrix4.Perspective(fovy,aspect,zNear,zFar);
            GL.MultMatrix(ref cc);

        }



        private static bool disampe(float v,float a,float b)
        {
            return v > a && b > v;
        }
        private static float der(float v)
        {
            if (v > 360f)
                return v - 360f;
            else
                return v;
        }
        public static  float AseimAngle(float angle)
        {
            angle = der(Math.Abs(angle));
        
            if (disampe(angle, 90f - 45, 90f + 45))
                return 90f;
            if (disampe(angle, 180f - 45, 180f + 45))
                return 180f;
            if (disampe(angle, 270f - 45, 270f + 45))
                return 270f;
            return 0f;

        }




        public static JVector TriangleNormal(JVector A,JVector B,JVector C)
        {
            float x1 = A.X;
            float x2 = B.X;
            float x3 = C.X;
            float y1 = A.Y;
            float y2 = B.Y;
            float y3 = C.Y;
            float z1 = A.Z;
            float z2 = B.Z;
            float z3 = C.Z;
            JVector vec = JVector.Zero;
            vec.X = (y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1);
            vec.Y = (z2 - z1) * (x3 - x1) - (z3 - z1) * (x2 - x1);
            vec.Z = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
            return vec;
        }





        public static void LookAt(JVector eye, JVector direction, JVector upv)
        {

            Matrix4 cc;
            cc = Matrix4.LookAt(
                eye.X, eye.Y, eye.Z,
                direction.X, direction.Y, direction.Z,
                upv.X, upv.Y, upv.Z
                );
            GL.MultMatrix(ref cc);

        }
        public static void LookAt(
            float eye1, float eye2, float eye3,
             float eye11, float eye21, float eye31,
              float eye12, float eye22, float eye32

            )
        {

            Matrix4 cc;
            cc = Matrix4.LookAt(
                eye1, eye2, eye3,
                eye11, eye21, eye31,
                eye12, eye22, eye32
                );
            GL.MultMatrix(ref cc);

        }






        static float[] TransformBuffer = new float[16];
        public static void SetTransform(JVector pos, JMatrix matrix)
        {

            TransformBuffer[0] = matrix.M11;
            TransformBuffer[1] = matrix.M12;
            TransformBuffer[2] = matrix.M13;
            TransformBuffer[3] = 0.0f;
            TransformBuffer[4] = matrix.M21;
            TransformBuffer[5] = matrix.M22;
            TransformBuffer[6] = matrix.M23;
            TransformBuffer[7] = 0.0f;
            TransformBuffer[8] = matrix.M31;
            TransformBuffer[9] = matrix.M32;
            TransformBuffer[10] = matrix.M33;
            TransformBuffer[11] = 0.0f;
            TransformBuffer[12] = pos.X;
            TransformBuffer[13] = pos.Y;
            TransformBuffer[14] = pos.Z;
            TransformBuffer[15] = 1f;


            fixed (float* c = &TransformBuffer[0])
            {
                GL.MultMatrix(c);
            }

        }
    }
}
