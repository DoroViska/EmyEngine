﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Runtime.InteropServices;
using EmyEngine.SDL2;
using EmyEngine;
using EmyEngine.Primitivs3D;
namespace EmyEngine.Imaging
{
    [Obsolete("Опасно! убери!")]
    public unsafe class DangerousBitmap : IColorMap
    {
        public int PixelSize = 4;
        public SDL_Surface* Surface { set; get; }
        public int Width { get { return Surface->w; } }
        public int Height { get { return Surface->h; } }
        public Color* Pixels { get { return (Color*)Surface->pixels; } }

        public void LockBits()
        {
            SDL.SDL_LockSurface(Surface);
        }
        public void UnLockBits()
        {
            SDL.SDL_UnlockSurface(Surface);
        }

        public void SetPixel(int x,int y, Color color)
        {
            this.Pixels[this.Width * (y - 1) + (x - 1)] = color;
        }

        public Color GetPixel(int x, int y)
        {     
            Color c = this.Pixels[this.Width * (y - 1) + (x - 1)];         
            return c;
        }



        public Color[] Dupe()
        {
            LockBits();
            Color[] rz = new Color[Width * Height];
            for (int i = 1; i < this.Width * this.Height; i++)
            {
                rz[i] = Pixels[i];
            }
            UnLockBits();
            return rz;
        }
        public Color[,] DupeDouble()
        {
            LockBits();
            Color[,] rz = new Color[Width,Height];
            fixed (Color* it = &rz[0,0])
            {
                for (int i = 1; i < this.Width * this.Height; i++)
                {
                    it[i] = Pixels[i];
                }
            }
            
            UnLockBits();
            return rz;
        }



        public void Replace(Color oldC,Color newC)
        {
            LockBits();
            for (int i = 0;i < this.Width * this.Height;i++)
            {
                if (Pixels[i] == oldC)
                {
                    
                    Pixels[i] = newC;
                }

            }
            UnLockBits();
        }


        public int GetArryNum(int x, int y)
        {           
            return this.Width * (y - 1) + (x - 1);
        }



        public void RotateY()
        {
            Color[] buffer = new Color[this.Width * this.Height];
            this.LockBits();
            //memscopy
            for (int i = 1; i < this.Width * this.Height; i++)
            {
                buffer[i] = Pixels[i];
            }

            for (int y = 1; y != this.Height; y++)
            {
                for (int x = 1; x != this.Width; x++)
                {
                    SetPixel(x, this.Height - y, buffer[GetArryNum(x, y)]);

                }

            }
            this.UnLockBits();

        }
        public void RotateX()
        {
            Color[] buffer = new Color[this.Width * this.Height];
            this.LockBits();
            //memscopy
            for (int i = 1; i < this.Width * this.Height; i++)
            {
                buffer[i] = Pixels[i];
            }

            for (int y = 1; y != this.Height; y++)
            {
                for (int x = 1; x != this.Width; x++)
                {
                    SetPixel(this.Width - x, y, buffer[GetArryNum(x, y)]);

                }

            }
            this.UnLockBits();
        }

        //[Obsolete("Просто забей, png the best, Bitmap PngFromFile(string name)")]
        public static DangerousBitmap FromFile(string name)
        {
            if (name == null || name == string.Empty)
                throw new ArgumentNullException(nameof(name));
            return FromStream(File.OpenRead(name));
        }
        //[Obsolete("Просто забей, png the best, Bitmap PngFromStream(Stream name)")]
        public static DangerousBitmap FromStream(Stream name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            byte[] rw = new byte[name.Length];
            name.Read(rw,0,rw.Length);
            name.Position = 0;
            void* mems = Marshal.AllocHGlobal(rw.Length).ToPointer();
            Marshal.Copy(rw,0, new IntPtr(mems), rw.Length);
            SDL_RWops* pops = SDL.SDL_RWFromMem(mems, rw.Length);

            DangerousBitmap b = new DangerousBitmap();
            b.Surface = SDL.IMG_Load_RW(pops, 1);

            if(b.Surface == null)           
                throw new Exception("Не удалось загрузить картинку!");
            
            if (b.Surface->format->BytesPerPixel != 4)
                throw new Exception("Картинки с форматом RGB-24 не поддерживаются!");
               
            //Console.WriteLine("[image loading] W = " + b.Surface->w + ", H = " + b.Surface->h);
            return b;
        }


    }
}
