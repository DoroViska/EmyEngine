﻿namespace EmyEngine.Imaging
{
    public interface IColorMap
    {
      
        int Height { get; }
        int Width { get; }

        int GetArryNum(int x, int y);
        Color GetPixel(int x, int y);
        void Replace(Color oldC, Color newC);
        void RotateX();
        void RotateY();
        void SetPixel(int x, int y, Color color);
    }
}