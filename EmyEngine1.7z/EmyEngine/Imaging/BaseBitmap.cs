﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using EmyEngine.SDL2;
using EmyEngine;
using EmyEngine.Primitivs3D;
using System.Runtime.InteropServices;
#pragma warning disable
namespace EmyEngine.Imaging
{
    public enum PixelColorsCounts : int
    {
        Color1 = 1,
        Color2 = 2,
        Color3 = 3,
        Color4 = 4
    }
    public enum ColorDelim : int
    {
        Float,
        Byte,
        Int32
    }

    public unsafe class BaseBitmap : IColorMap
    {

    
        public PixelColorsCounts OnePixel { private set; get; }
        public int Width { private set; get;}
        public int Height { private set; get; }


        public Color[,] ColorMap { private set; get; }
       
        public void SetPixel(int x, int y, Color color)
        {
            if (x > this.Width || x < 0)
                throw new ArgumentOutOfRangeException("Пиксель X не может быть '> Width' и '< 0'");
            if (y > this.Height || y < 0)
                throw new ArgumentOutOfRangeException("Пиксель Y не может быть '> Height' и '< 0'");
            fixed (Color* Pixels = &ColorMap[0, 0])
            {
                Pixels[this.Width * (y - 1) + (x - 1)] = color;
            }
        }

        public Color GetPixel(int x, int y)
        {
            if (x > this.Width || x < 0)
                throw new ArgumentOutOfRangeException("Пиксель X не может быть '> Width' и '< 0'");
            if (y > this.Height || y < 0)
                throw new ArgumentOutOfRangeException("Пиксель Y не может быть '> Height' и '< 0'");
            fixed (Color* Pixels = &ColorMap[0, 0])
            {
                Color c = Pixels[this.Width * (y - 1) + (x - 1)];
                return c;
            }
           
        }




        


        public void RotateY()
        {
            //  Console.WriteLine(GetPixel(0,3) + " :::: " + ColorMap[0,3]);

            fixed (Color* Pixels = &ColorMap[0, 0])
            {
                Color[] buffer = new Color[this.Width * this.Height];

                //memscopy
                for (int i = 1; i < this.Width * this.Height; i++)
                {
                    buffer[i] = Pixels[i];
                }

                for (int y = 1; y != this.Height; y++)
                {
                    for (int x = 1; x != this.Width; x++)
                    {
                        SetPixel(x, this.Height - y, buffer[GetArryNum(x, y)]);

                    }

                }
       
            }

        }




        public void RotateX()
        {
            fixed (Color* Pixels = &ColorMap[0, 0])
            {
                Color[] buffer = new Color[this.Width * this.Height];

                //memscopy
                for (int i = 1; i < this.Width * this.Height; i++)
                {
                    buffer[i] = Pixels[i];
                }

                for (int y = 1; y != this.Height; y++)
                {
                    for (int x = 1; x != this.Width; x++)
                    {
                        SetPixel(this.Width - x, y, buffer[GetArryNum(x, y)]);

                    }

                }
            }
        }






        public int GetArryNum(int x, int y)
        {
            if (x > this.Width || x < 0)
                throw new ArgumentOutOfRangeException("Пиксель X не может быть '> Width' и '< 0'");
            if (y > this.Height || y < 0)
                throw new ArgumentOutOfRangeException("Пиксель Y не может быть '> Height' и '< 0'");
            return this.Width* (y - 1) + (x - 1);
        }


        public void Replace(Color oldC, Color newC)
        {
            fixed (Color* Pixels = &ColorMap[0,0])
            {
                for (int i = 0; i < this.Width * this.Height; i++)
                {
                    if (Pixels[i] == oldC)
                    {

                        Pixels[i] = newC;
                    }

                }
            }
            
        }


     


        public ColorDelim ColorDelim { get { return ColorDelim.Byte; } }


        public BaseBitmap(string filename)
        {
            if (filename == null || filename == string.Empty)
                throw new ArgumentNullException(nameof(filename));
            Stream cc = File.OpenRead(filename);
            LoadFromStream(cc);
            cc.Close();
        }
        public BaseBitmap(Stream file_rw_stream)
        {          
            LoadFromStream(file_rw_stream);
        }
        public BaseBitmap(byte[] file_rw)
        {
            Stream cc = new MemoryStream(file_rw);
            LoadFromStream(cc);
            cc.Close();        
        }


        private void LoadFromStream(Stream strea)
        {
            if (strea == null)
                throw new ArgumentNullException(nameof(strea));

          


            byte[] stream_data = new byte[strea.Length];
            strea.Read(stream_data, 0, stream_data.Length);
            strea.Position = 0;

            // void* mems = Marshal.AllocHGlobal(stream_data.Length).ToPointer();
            // Marshal.Copy(rw, 0, new IntPtr(mems), rw.Length);
            //Нативный конвертер 
            fixed (byte* dta = &stream_data[0])
            {
                SDL_RWops* pops = SDL.SDL_RWFromMem(dta, stream_data.Length);
                if (pops == null)
                    throw new FunctionReturnedNullException("SDL_RWFromMem");
                SDL_Surface* sf = SDL.IMG_Load_RW(pops, 1);
                if (sf == null)
                    throw new FunctionReturnedNullException("IMG_Load_RW");

                PixelColorsCounts ct;
                if (sf->format->BytesPerPixel == 4)
                    ct = PixelColorsCounts.Color4;
                else if (sf->format->BytesPerPixel == 3)
                    ct = PixelColorsCounts.Color3;
                else if (sf->format->BytesPerPixel == 1)
                    ct = PixelColorsCounts.Color1;
                else
                    throw new BitMapBadFormatException(sf->format->BytesPerPixel);

                int alllen = sf->h * sf->w;
                Color[,] rz_mp = new Color[sf->w, sf->h];

                if (ct == PixelColorsCounts.Color1)
                {


                    for (int display = 0; display < (alllen); display++)
                    {
                        UniColor1 cur = ((UniColor1*)sf->pixels)[display];
                        fixed (Color* p = &rz_mp[0, 0])
                        {
                            Color* pix = p + display;
                            pix->A = 255;
                            pix->R = cur.C;
                            pix->G = cur.C;
                            pix->B = cur.C;
                        }


                    }
                }
                if (ct == PixelColorsCounts.Color3)
                {
                    
                   
                    for (int display = 0; display < (alllen); display++)
                    {
                        UniColor3 cur = ((UniColor3*) sf->pixels)[display];
                        fixed (Color* p = &rz_mp[0,0])
                        {
                            Color* pix = p + display;
                            pix->A = 255;
                            pix->R = cur.R;
                            pix->G = cur.G;
                            pix->B = cur.B;
                        }


                    }
                }
                if (ct == PixelColorsCounts.Color4)
                {


                    for (int display = 0; display < (alllen); display++)
                    {
                        UniColor4 cur = ((UniColor4*)sf->pixels)[display];
                        fixed (Color* p = &rz_mp[0, 0])
                        {
                            Color* pix = p + display;
                            pix->A = cur.A;
                            pix->R = cur.R;
                            pix->G = cur.G;
                            pix->B = cur.B;
                        }


                    }
                }
                LoadThis(ct,ColorDelim.Byte,sf->w,sf->h, rz_mp);

               if (sf != null)
                    SDL.SDL_FreeSurface(sf);
                if(pops != null)
                   SDL.SDL_FreeRW(pops);
            }
           
          
        }

        [Obsolete("Опасный метод")]
        internal void LoadThis(PixelColorsCounts ct, ColorDelim pixtype, int w, int h, Color[,] allocatedPixels)
        {
            if (allocatedPixels == null)
                throw new ArgumentNullException(nameof(allocatedPixels));
            if (w == 0)
                throw new ArgumentOutOfRangeException(nameof(w));
            if (h == 0)
                throw new ArgumentOutOfRangeException(nameof(h));
            if (pixtype != ColorDelim.Byte)
            {
                throw new NotSupportedException("кроме байта в пикселе больше ничё не спортится!");
            }


            this.OnePixel = ct;
            this.Width = w;
            this.Height = h;
            this.ColorMap = allocatedPixels;
        }
        [Obsolete("Опасный метод")]
        internal void LoadThis(PixelColorsCounts ct, ColorDelim pixtype, Color[,] allocatedPixels)
        {
            if (allocatedPixels == null)
                throw new ArgumentNullException(nameof(allocatedPixels));
            if (allocatedPixels.GetLength(0) == 0)
                throw new ArgumentOutOfRangeException(nameof(allocatedPixels));
            if (allocatedPixels.GetLength(1) == 0)
                throw new ArgumentOutOfRangeException(nameof(allocatedPixels));
            if (pixtype != ColorDelim.Byte)
            {
                throw new NotSupportedException("кроме байта в пикселе больше ничё не спортится!");
            }


            this.OnePixel = ct;
            this.Width = allocatedPixels.GetLength(0);
            this.Height = allocatedPixels.GetLength(1);
            this.ColorMap = allocatedPixels;
        }

    }
}
