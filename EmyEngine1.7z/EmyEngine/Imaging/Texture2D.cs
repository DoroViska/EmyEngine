﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;

namespace EmyEngine.Imaging
{

    public unsafe class Texture2D
    {
   
        public Texture2D()
        {
            uint b;
            GL.GenTextures(1, &b);
            this.Texture = b;

            RotateFlip = true;
        }

        public void Bind()
        {

            GL.Enable(EnableCap.Texture2D);
            GL.BindTexture(TextureTarget.Texture2D, Texture);
        }
        public void EndBind()
        {
            GL.Disable(EnableCap.Texture2D);
        }

        public uint Texture { set; get; }
        public int Width { set; get; }
        public int Height { set; get; }
        public bool RotateFlip { set; get; }

        public Texture2D(BaseBitmap image,bool roteate_flip = true,bool wrap_s = false) : this()
        {
            RotateFlip = roteate_flip;
            if (image == null)
                throw new ArgumentNullException(nameof(image));
            if (RotateFlip)
              image.RotateY();

            this.Width = image.Width;
            this.Height = image.Height;
            Bind();
            fixed(Color* t = &image.ColorMap[0, 0])
            {
                //glTexImage2D(GL_TEXTURE_2D, 0, (int)GL_RGBA, image.Widith, image.Heigth, 0, GL_RGBA, GL_UNSIGNED_BYTE,(void*) t);
                //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, (int)GL_LINEAR);

                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, image.Width, image.Height, 0, PixelFormat.Rgba, OpenTK.Graphics.OpenGL.PixelType.UnsignedByte,new IntPtr(t));

                GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMinFilter,(int)TextureMagFilter.Linear);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
                if (wrap_s)
                {
                    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)All.Repeat);
                    GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)All.Repeat);
                }

            }
            EndBind();
           
           if (RotateFlip)
                image.RotateY();
        }

        /// <summary>
        ///  import, one pixel it's 4 bytes -> RGBA
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        public Texture2D(byte[] bytes,int w,int h) : this()
        {
            if (bytes.Length == 0)
                throw new ArgumentOutOfRangeException(nameof(bytes));
            if (w == 0)
                throw new ArgumentOutOfRangeException(nameof(w));

            if (h == 0)
                throw new ArgumentOutOfRangeException(nameof(h));
           

            Bind();
            this.Width = w;
            this.Height = h;
            //glTexImage2D(GL_TEXTURE_2D, 0, (int)GL_RGBA, w, h, 0, 0x80E1, GL_UNSIGNED_BYTE, bytes);
            //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, (int)GL_LINEAR);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, w, h, 0, PixelFormat.Rgba, OpenTK.Graphics.OpenGL.PixelType.UnsignedByte,bytes);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            EndBind();
        }
    }

}
