﻿namespace EmyEngine
{
    public unsafe interface IGLView
    {
        int Height { get; set; }
        bool IsRunning { get; set; }
        string Title { get; set; }
        int Width { get; set; }

        //event Frameing Frameing;
        event KeyPresed KeyPresed;
        event Loaded Loaded;
        event Render Render;
        event Resized Resized;

        void* TryToGetWindowPtr();


        void Close();
        void Dispose();
        void FullScrinDisable();
        void FullScrinEnabale();
        //void OnFrameing(IGLView sender);
        void OnKeyPresedd(IGLView sender, int keycode);
        void OnLoaded(IGLView sender);
        void OnRender(IGLView sender);
        void OnResized(IGLView sender);
        void Run(bool fullsc = true);
        void Swap();
    }
}