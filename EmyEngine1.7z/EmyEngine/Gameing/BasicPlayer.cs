﻿using Jitter.Collision.Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine.Gameing.BasicConstraint;
using Jitter.LinearMath;
using OpenTK.Input;

namespace EmyEngine.Gameing
{
    public class BasicPlayer : GameObject
    {

        public FlyingCamera Camera { private set; get; } = null;


        private CharacterController controller = null;
        public BasicPlayer()
        {
            this.Body = new ObjectivBody(this, new CapsuleShape(1.0f, 0.1f));
            this.Body.Mass = 80;
            this.Body.Material.KineticFriction = 0f;
            this.Body.Material.StaticFriction = 0f;
            this.Body.Material.Restitution = 0f;
            Camera = new FlyingCamera();
            Camera.MyConvision = false;
            Camera.AngleX = (float)Math.PI / 2;
            Camera.AngleY = (float)Math.PI / 2;

        }


        public override void AddedToInstance(GameInstance instance)
        {
            controller = new CharacterController(instance.World,this.Body);
            this.Body.SetMassProperties(JMatrix.Zero, 1.0f, true);
            this.Body.Material.Restitution = 0.0f;

            instance.World.AddConstraint(controller);
        }

        public override void Draw()
        {
            
        }

        public override void Update()
        {

           



            KeyboardState keyState = Keyboard.GetState();
            JVector targetVelocity = JVector.Zero;
            if (keyState.IsKeyDown(Key.W))
            {
                targetVelocity += (new JVector(
                   (float)Math.Cos(this.Camera.AngleX) * 1
                   ,
                   0,
                   (float)Math.Sin(this.Camera.AngleX) * 1
                   ));
            }
            if (keyState.IsKeyDown(Key.S))
            {
                targetVelocity += (new JVector(
                  (float)Math.Cos(this.Camera.AngleX) * -1
                  ,
                  0,
                  (float)Math.Sin(this.Camera.AngleX) * -1
                  ));
            }
            if (keyState.IsKeyDown(Key.A))
            {
                targetVelocity += (new JVector(
                ((float)Math.Cos(this.Camera.AngleX + (float)Math.PI / 2)) * -1
                ,
                0,
                 ((float)Math.Sin(this.Camera.AngleX + (float)Math.PI / 2)) * -1
                ));
            }
            if (keyState.IsKeyDown(Key.D))
            {
                targetVelocity += (new JVector(
                        ((float)Math.Cos(this.Camera.AngleX + (float)Math.PI / 2)) * 1
                        ,
                        0,
                         ((float)Math.Sin(this.Camera.AngleX + (float)Math.PI / 2)) * 1
                        ));
            }

            if (targetVelocity.LengthSquared() > 0.0f) targetVelocity.Normalize();
            targetVelocity *=3.0f;
            //targetVelocity += new JVector(0f,0.0000001f,0f);
            if(keyState.IsKeyDown(Key.ShiftLeft))
                targetVelocity *= 2.0f;
            controller.TryJump = keyState.IsKeyDown(Key.Space);

            controller.TargetVelocity = targetVelocity;
            Camera.HeadPosition = this.Body.Position + new JVector(0f, 0.6f, 0f);
            this.Body.IsActive = true;
        }
    }
}
