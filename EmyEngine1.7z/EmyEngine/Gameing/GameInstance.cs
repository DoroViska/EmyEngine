﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
namespace EmyEngine.Gameing
{
    public class GameInstance
    {
        ~GameInstance()
        {

        }



        public GameInstance()
        {
            GameObjects = new List<GameObject>();
            this.WorldCollisionSystem = new CollisionSystemBrute();
            this.WorldCollisionSystem.CollisionDetected += WorldCollisionSystem_CollisionDetected;
            this.World = new World(this.WorldCollisionSystem);
           // this.World.Gravity = new JVector(0f,-10f,0f);
        }

        private void WorldCollisionSystem_CollisionDetected(RigidBody body1, RigidBody body2, JVector point1, JVector point2, JVector normal, float penetration)
        {
            
        }

        public bool UsingMultiThreding { set; get; } = true;

        public void Update(float step)
        {
            World.Step(step, UsingMultiThreding);
            for (int objid = 0; objid < this.GameObjects.Count; objid++)
            {
                this.GameObjects[objid].Update();

            }
        }

        private bool debug_draweble = false;
        public void EnableDebugDraweble()
        {
            debug_draweble = true;
            foreach (GameObject obj in GameObjects)
            {
                obj.Body.EnableDebugDraw = true;
            }
        }
        public void DisableDebugDraweble()
        {
            debug_draweble = false;
            foreach (GameObject obj in GameObjects)
            {
                obj.Body.EnableDebugDraw = false;
            }
        }

        private List<GameObject> GameObjects { set; get; }

        public GameObject this[int nindex]
        {
            get { return GameObjects[nindex]; }
        }

        public int Length { get { return this.GameObjects.Count; } }


        public World World { private set; get;}
        public CollisionSystem WorldCollisionSystem { private set; get; }


        public void AddObject(GameObject obj)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));
            if (obj.Body == null)
                throw new ObjectBodyIsNullException();
            if (debug_draweble)
                obj.Body.EnableDebugDraw = true;


            obj.Instance = this;         
            World.AddBody(obj.Body);           
            GameObjects.Add(obj);

            obj.AddedToInstance(this);
        }
        public void RemoveObject(GameObject obj)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));

            obj.Instance = null;      
            World.RemoveBody(obj.Body);
            GameObjects.Remove(obj);

            obj.RemovedFromInstance(this);
        }

        public void ClearObjects()
        {
            GameObjects.Clear();
            World.Clear();
            foreach (GameObject obj in GameObjects)
            {
                obj.Instance = null;
                obj.RemovedFromInstance(this);
            }
        }

        public void UpdateInstanceObject(GameObject obj)
        {
            obj.Instance = this;        
        }


    }
}
