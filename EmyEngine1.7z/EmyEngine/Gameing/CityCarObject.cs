﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Jitter.Collision.Shapes;
using Jitter;
using Jitter.LinearMath;

using EmyEngine;

using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using OpenTK.Input;
using OpenTK.Graphics.OpenGL;
using EmyEngine.Gameing;
using EmyEngine.ResourceManagment;
using EmyEngine.Models3D;
#endregion

namespace EmyEngine.Gameing
{
    public class CityCarObject : GameObject
    {
        
        Model3D sc = null;
        Model3D wc = null;
        public CityCarObject()
        {


            sc = GameEngine.CurrentModels.GetModel("city_car.m3d");
            wc = GameEngine.CurrentModels.GetModel("base_wheel.m3d");
            //CompoundShape.TransformedShape lower = new CompoundShape.TransformedShape(
            //    new BoxShape(2.7f, 1.3f, 5.0f), JMatrix.Identity, new JVector(0, 3f, 1.0f));

            //CompoundShape.TransformedShape upper = new CompoundShape.TransformedShape(
            //   new BoxShape(2.7f, 2.0f, 3.0f), JMatrix.Identity, new JVector(0, 3.6f, 1f));

            CompoundShape.TransformedShape lower = new CompoundShape.TransformedShape(
            new BoxShape(2.0f, 1.4f, 5.0f), JMatrix.Identity, new JVector(0, 1.0f, 6f));

            //CompoundShape.TransformedShape upper = new CompoundShape.TransformedShape(
            //    new BoxShape(2.7f, 0.8f, 3.0f), JMatrix.Identity, new JVector(0, 1.0f, 1f));


            CompoundShape.TransformedShape[] subShapes = { lower  };

            CompoundShape chassis = new CompoundShape(subShapes);

            //chassis = new BoxShape(2.5f, 1f, 6.0f);

          

         
            Body = new DefaultCar(this, chassis);
            Body.Mass = 2000f;

            Wheel[] wheels = new Wheel[4];
            wheels[(int)WheelPosition.FrontLeft] = new Wheel(Body, new JVector(0, -0.3f, -0.49f) + JVector.Left + 1.8f * JVector.Forward + 0.8f * JVector.Down, 0.35f);
            wheels[(int)WheelPosition.FrontRight] = new Wheel(Body, new JVector(0, -0.3f, -0.49f) + JVector.Right + 1.8f * JVector.Forward + 0.8f * JVector.Down, 0.35f);

            wheels[(int)WheelPosition.BackLeft] = new Wheel(Body, new JVector(0, -0.3f, -1.1f) + JVector.Left + 1.8f * JVector.Backward + 0.8f * JVector.Down, 0.35f);
            wheels[(int)WheelPosition.BackRight] = new Wheel(Body, new JVector(0, -0.3f, -1.1f) + JVector.Right + 1.8f * JVector.Backward + 0.8f * JVector.Down, 0.35f);


          
           
            // use the inertia of the lower box.

            // adjust some driving values

            //угол поворта
            ((DefaultCar)Body).SteerAngle = 30;
            //крутящий момент
            ((DefaultCar)Body).DriveTorque = 30;

            //ускарение
            ((DefaultCar)Body).AccelerationRate = 400f;
            //ускорение поврота
            ((DefaultCar)Body).SteerRate = 18f;
            ((DefaultCar)Body).AdjustWheelValues(wheels);
            
           // carBody.Tag = BodyTag.DontDrawMe;
            Body.AllowDeactivation = false;

            // place the car two units above the ground.
            Body.Position = new JVector(0, 2, 0);

         //   world.AddBody(Body);
        }

        public override void Update()
        {
            KeyboardState keyState = Keyboard.GetState();

            float steer, accelerate;
            if (keyState.IsKeyDown(Key.Up))
                accelerate = 50.0f;
            else if (keyState.IsKeyDown(Key.Down))
                accelerate = -50.0f;
            else accelerate = 0.0f;

            if (keyState.IsKeyDown(Key.Left))
                steer = 1;
            else if (keyState.IsKeyDown(Key.Right))
                steer = -1;
            else
                steer = 0.0f;

        

            ((DefaultCar)Body).SetInput(accelerate, steer);

         
        }
        CylinderPrimitive pm = new CylinderPrimitive();

        public override void Draw()
        {

         //   GameObjectJShape.RenderShape(this.Body.Shape, this.Body.Position,this.Body.Orientation);

            GL.PushMatrix();
         
            Transformator.SetTransform(Body.Position, Body.Orientation);

            GL.Rotate(-90, 1f, 0f, 0f);
            GL.Rotate(180, 0f, 0f, 1f);

            //уменьшим в размерах
            // GL.Scale(0.7f, 0.7f, 0.7f);
            GL.Scale(6.7f, 6.7f, 6.7f);


            //вниз отпустим малёх
            //GL.Translate(0f ,-0.7f, -2.1f);
            GL.Translate(0f, -0.1f, -0.05f);



            sc.Draw();
            GL.PopMatrix();

          
            for (int i = 0; i < ((DefaultCar)Body).Wheels.Length; i++)
            {
                GL.PushMatrix();
                Wheel wheel = ((DefaultCar)Body).Wheels[i];


              

           

                Transformator.SetTransform(wheel.GetWorldPosition(), Body.Orientation);
      
                Transformator.SetTransform(JVector.Zero, JMatrix.CreateRotationY(wheel.SteerAngle * (float)Math.PI / 180));
                Transformator.SetTransform(JVector.Zero, JMatrix.CreateRotationX(-wheel.WheelRotation * (float)Math.PI / 180));


              
                GL.Rotate(90f, 0f, 0f, 1f);
                GL.Color3(0.5f, 0.5f, 0.5f);
              
                GL.Scale(
                     wheel.Radius + 0.14f,
                   0.6f,
                 wheel.Radius + 0.14f
                    );
               // pm.Draw();
                wc.Draw();
                GL.Color3(1f, 1f, 1f);
                GL.PopMatrix();
            }
            
        }


    }
}
