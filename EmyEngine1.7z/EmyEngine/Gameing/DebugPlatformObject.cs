﻿using Jitter.Collision.Shapes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.Gameing
{
    public class DebugPlatformObject : GameObjectJShape
    {
       
        public DebugPlatformObject() : base(new BoxShape(300, 1, 300))
        {
            Body.IsStatic = true;
            Body.Material.KineticFriction = 1f;
            Body.Material.StaticFriction = 1f;
        }
    }
}
