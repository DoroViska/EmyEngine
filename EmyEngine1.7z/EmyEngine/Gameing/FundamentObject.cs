﻿using EmyEngine.Models3D;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.Gameing
{
    public class FundamentObject : GameObject
    {
        public Model3D model = null;

        public FundamentObject()
        {

            model = GameEngine.CurrentModels.GetModel("fundament.m3d");
            Body = new ObjectivBody(this, new BoxShape(new JVector(2f, 2f, 2f)));

        }


        public override void Draw()
        {
            GL.PushMatrix();
            Transformator.SetTransform(Body.Position, Body.Orientation);
            model.Draw();
            GL.PopMatrix();
        }

        public override void Update()
        {
            
        }
    }
}
