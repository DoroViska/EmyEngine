﻿using Jitter.LinearMath;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;

namespace EmyEngine.Gameing
{

    public class NotSafebleGameObject : Attribute
    {


    }

    [Serializable]
    public class sMission
    {

        public List<sObject> Objects;

    }
    [Serializable]
    public class sObject
    {
        [XmlAttribute]
        public string ObjectName;
        [XmlAttribute]
        public string Name;
        public JVector Position;
        public JMatrix Orientation;
    }



    public class MissionLoader
    {
        public GameInstance Instance { private set; get; }


        sMission mission;
        public MissionLoader(GameInstance insabce_)
        {
            Instance = insabce_;

        }



        void load()
        {
            Instance.ClearObjects();
            foreach (sObject obj in mission.Objects)
            {
                GameObject obj1 = (GameObject)Assembly.GetExecutingAssembly().CreateInstance(obj.ObjectName);
                obj1.Position = obj.Position;
                obj1.Orientation = obj.Orientation;
                obj1.Name = obj.Name;

                Instance.AddObject(obj1);
            }

        }

        void save()
        {
            mission = new sMission();
            mission.Objects = new List<sObject>();
            for (int i = 0;i < Instance.Length;i++)
            {
                GameObject obj = Instance[i];
                Type t = obj.GetType();
                sObject add = new sObject();
                add.ObjectName = t.FullName;
                add.Name = obj.Name;
                add.Position = obj.Position;
                add.Orientation = obj.Orientation;
                mission.Objects.Add(add);
            }


        }

        public void Load(string source)
        {
            XmlSerializer s = new XmlSerializer(typeof(sMission));
            MemoryStream str = new MemoryStream(Encoding.UTF8.GetBytes(source));
            mission = (sMission)s.Deserialize(new StreamReader(str));
            load();
        }
        public string Save()
        {
            save();
            XmlSerializer s = new XmlSerializer(typeof(sMission));

            MemoryStream st = new MemoryStream();
            StreamWriter w = new StreamWriter(st);

            s.Serialize(w, mission);
            st.Position = 0;
            StreamReader r = new StreamReader(st);

            return r.ReadToEnd();
        }






    }
}
