﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
using EmyEngine.Models3D;
using OpenTK.Graphics.OpenGL;

namespace EmyEngine.Gameing
{
    public class WoodObject : GameObject
    {
        public Model3D model = null;
        public WoodObject()
        {
            model = GameEngine.CurrentModels.GetModel("wood.m3d");
            Body = new ObjectivBody(this,new BoxShape(new JVector(2f,2f,0.2f)));
            Body.IsStatic = false;
            Body.Mass = 2000f;
        }

        public override void Draw()
        {
            GL.PushMatrix();
            Transformator.SetTransform(Body.Position, Body.Orientation);
            model.Draw();
            GL.PopMatrix();
        }

        public override void Update()
        {
            
        }
    }
}
