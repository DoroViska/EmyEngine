﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
namespace EmyEngine.Gameing
{
    public abstract class GameObject
    {
        #region IDContenter
        public static uint NextID = 0;
        public static uint TakeID() { NextID++; return NextID; }
        public uint ID = TakeID();
        #endregion
        #region overrides
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is GameObject))
                return false;
            if (((GameObject)obj).ID == this.ID)
                return true;
            else
                return false;         
        }
        public override int GetHashCode()
        {
            return (int)this.ID;
        }
        public override string ToString()
        {
            return string.Format("GameObject: name = {0}, id = {1}, position = {2}",this.Name,this.ID,this.Body?.Position);
        }
        #endregion

        public abstract void Draw();
        public abstract void Update();

        public virtual void AddedToInstance(GameInstance instance)
        {

        }
        public virtual void RemovedFromInstance(GameInstance instance)
        {

        }


        public string Name { set; get; }   
        public ObjectivBody Body { set; get;}
        public float HP { set; get; }

       
        public GameInstance Instance { set; get; }



        public JMatrix Orientation {
            set { Body.Orientation = value; }
            get { return Body.Orientation;  }
        }
        public JVector Position {
            set { Body.Position = value; }
            get { return Body.Position; }
        }
        public float Mass
        {
            set { Body.Mass = value; }
            get { return Body.Mass; }
        }
        public Material Material
        {
            set { Body.Material = value; }
            get { return Body.Material; }
        }


    }
}
