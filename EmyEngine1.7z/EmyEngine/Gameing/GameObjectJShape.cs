﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Jitter.LinearMath;
using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;

using OpenTK.Graphics.OpenGL;

namespace EmyEngine.Gameing
{
    [NotSafebleGameObject]
    public class GameObjectJShape : GameObject
    {


        static GridPrimitive prt;
        static SpherePrimitive spt;
        static BoxPrimitive bxt;
        static CylinderPrimitive cyl;
        static bool ModelsIneted = false;


        public GameObjectJShape(Shape shape)
        {
            sh = shape;
            if (!ModelsIneted)
            {
                prt = new GridPrimitive();
                spt = new SpherePrimitive();
                bxt = new BoxPrimitive();
                cyl = new CylinderPrimitive();
                ModelsIneted = true;
            }

            this.Body = new ObjectivBody(this,sh);
        }

        Shape sh;
     
        public override void Draw()
        {
            if (!(this.Body.Tag is bool))
            {
                RenderShape(this.sh, this.Body.Position,this.Orientation);
            }            
        }

        public override void Update()
        {
            
        }

        public static void RenderShape(Shape sh, JVector pos,JMatrix orient)
        {
            if (sh is BoxShape)
            {
                GL.PushMatrix();
                Transformator.SetTransform(pos, orient);
                GL.Scale(((BoxShape)sh).Size.X, ((BoxShape)sh).Size.Y, ((BoxShape)sh).Size.Z);
                bxt.Draw();
                GL.PopMatrix();
            }
            if (sh is SphereShape)
            {
                GL.PushMatrix();
                Transformator.SetTransform(pos, orient);
                GL.Scale(((SphereShape)sh).Radius, ((SphereShape)sh).Radius, ((SphereShape)sh).Radius);
                spt.Draw();
                GL.PopMatrix();

            }
            if (sh is CylinderShape)
            {
                GL.PushMatrix();
                Transformator.SetTransform(pos, orient);
                GL.Scale(
                     ((CylinderShape)sh).Radius,
                   ((CylinderShape)sh).Height,
                   ((CylinderShape)sh).Radius
                    );
                cyl.Draw();
                GL.PopMatrix();

            }

            if (sh is CompoundShape)
            {

                foreach (CompoundShape.TransformedShape ccc in ((CompoundShape)sh).Shapes)
                {
                    GL.PushMatrix();
                    Transformator.SetTransform(pos,orient);

                 //   Console.WriteLine();
                    RenderShape(ccc.Shape, ccc.Position, ccc.Orientation);

                    GL.PopMatrix();
                }



            }

        }

    }
}
