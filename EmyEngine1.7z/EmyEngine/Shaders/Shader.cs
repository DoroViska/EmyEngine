﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;

using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using Jitter;
using Jitter.Collision;
using Jitter.Dynamics;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;

namespace EmyEngine.Shaders
{
    public unsafe class Shader
    {


        public string VertexSources { private set; get; }
        public string FragmentSources { private set; get; }

        public int VertexID { private set; get; }
        public int FragmentID { private set; get; }
        public int ProgramID { private set; get; }


        public Shader() : this(
@"attribute vec2 coord; 
void main() { 
    gl_Position = vec4(coord, 0.0, 1.0);
}",
@"uniform vec4 color;
void main() { 
    gl_FragColor = color;
}")
        {      

        }
        public Shader(string sV, string sF)
        {

            this.VertexSources = sV;
            this.FragmentSources = sF;

            Compilete();


        }

        static private void ShaderLog(int shader)
        {

            int infologLen = 0;
            int charsWritten = 0;
    

            GL.GetShader(shader, ShaderParameter.InfoLogLength, &infologLen);

            if (infologLen > 1)
            {
                StringBuilder ste = new StringBuilder(infologLen);
                GL.GetShaderInfoLog(shader, infologLen, &charsWritten, ste);
                Console.WriteLine("[Shader log]: "+ste);
            }


        }

        private void Compilete()
        {
            VertexID = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(VertexID, 1,new string[] { VertexSources }, (int*)null); 
            GL.CompileShader(VertexID);
            ShaderLog(VertexID);
            FragmentID = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(FragmentID, 1, new string[] { FragmentSources},(int*) null);
            GL.CompileShader(FragmentID);
            ShaderLog(FragmentID);

            ProgramID = GL.CreateProgram();
            GL.AttachShader(ProgramID, VertexID);
            GL.AttachShader(ProgramID, FragmentID);

            // ! Линкуем шейдерную программу
            GL.LinkProgram(ProgramID);

            int link_ok;
            GL.GetProgram(ProgramID,GetProgramParameterName.LinkStatus, &link_ok);
            if (!(link_ok != 0))
            {
                throw new Exception("Оишбка устанвоки Шейдоров: " + this.ProgramID + ", " + this.VertexID + ", " + this.FragmentID);
            }



        }









      




    }
}
