﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine
{
    public class Model3DNotFoundException : Exception
    {
        public Model3DNotFoundException(string modelName) : base("Не удалось найти 3D модель: " + modelName) { }
    }

    public class ResourceNotFoundException : Exception
    {
        public ResourceNotFoundException(string ResourcePath) : base("Не удалось найти ресурс: " + ResourcePath) { }
    }

    public class FunctionReturnedNullException : Exception
    {
        public FunctionReturnedNullException(string funcname) : base(funcname + ": вернула NULL") { }
    }

    public class BitMapBadFormatException : Exception
    {
        public BitMapBadFormatException(int bytes_per_pixels) : base("поддерживаются картинки только с форматом RGB-8,RGB-24,RGBA-32. Требуемый формат ?-" + bytes_per_pixels + " байт") { }
    }

    public class PropetryNotInitializeException : Exception
    {
        public PropetryNotInitializeException(string name) : base("Ресурс не инициализирован: " + name) { }
    }
    public class ObjectBodyIsNullException : Exception
    {
        public ObjectBodyIsNullException() : base("Обьект содержит тело равное = NULL") { }
    }
    public class CurrentGraphicsIsNotDrawebleException : Exception
    {
        public CurrentGraphicsIsNotDrawebleException() : base("Установка пыталасть нарисовать, кога рисовать нелзя!") { }
    }


    public class __std_badOpCode_fromatException : Exception
    {
        public __std_badOpCode_fromatException() : base("[]: Метод прервал свою работу из-за отсутсвия бинарного кода")
        {

        }
    }
    //public class Exceptions
    //{
    //}
}
