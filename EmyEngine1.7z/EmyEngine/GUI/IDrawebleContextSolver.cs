﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public interface IDrawebleContextSolver
    {
        float ZCounter { set; get; }
        int GetWidth();
        int GetHeight();
        bool IsDraweble();
        IGraphics2D CreateGraphics();
    }
}
