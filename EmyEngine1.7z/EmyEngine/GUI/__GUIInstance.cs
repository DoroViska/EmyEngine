﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmyEngine.SDL2;
namespace EmyEngine.GUI
{


   



    public unsafe class __GUIInstance
    {
        class BasicResolver : IDrawebleContextSolver
        {
            public BasicResolver(__GUIInstance instance)
            {
                this_t = instance;
            }
            __GUIInstance this_t;

            public float ZCounter
            {
                set; get;
            }

            public int GetHeight()
            {
                return this_t.Height;
            }

            public int GetWidth()
            {
                return this_t.Width;
            }

            public bool IsDraweble()
            {
                return true;
            }

            public IGraphics2D CreateGraphics()
            {
                throw new NotImplementedException();
            }
        }
        public IDrawebleContextSolver DrawebleSolver { private set; get; }

        public __GUIInstance()
        {
            DrawebleSolver = new BasicResolver(this);
           
        }




        public List<__Widget> Items { private set; get; } = new List<__Widget>();


        public int Width { set; get; }
        public int Height { set; get; }

        private int OldW = 0;
        private int OldH = 0;
        public static bool RecolarPos2DX(Point c1Min, Point c1Max, Point c2Min, Point c2Max)
        {
            if ((c1Max.X >= c2Min.X && c1Min.X <= c2Max.X) == false) return false;
            if ((c1Max.Y >= c2Min.Y && c1Min.Y <= c2Max.Y) == false) return false;
            return true;
        }

        public void Update(int window_width,int window_height)
        {

            this.Width = window_width;
            this.Height = window_height;

            int x;
            int y;
            uint mouse = SDL.SDL_GetMouseState(&x,&y);
            WindowLoop(Items,x,y,mouse,this.Width,this.Height);

            if (OldW == 0)
                OldW = Width;
            if (OldH == 0)
                OldH = Height;

            if (OldW != Width)
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    __Widget o = Items[i];
                    o.Resize(Width - OldW,0);
                    
                }
                OldW = Width;
            }
            if (OldH != Height)
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    __Widget o = Items[i];
                    o.Resize(0, Height - OldH);

                }
                OldH = Height;

            }
        }



        public static void WindowLoop(List<__Widget> Items, int x,int y,uint mouse,int w,int h)     
        {
 
            for (int i = 0;i < Items.Count;i++)
            {
                __Widget o = Items[i];
                if (!RecolarPos2DX(o.Position, o.PositionMax, new Point(0, 0), new Point(w, h)))
                {

                    continue;
                }


                if (o.IsVisable == false) continue;
                o.Updated( x,  y,  mouse);
                if (RecolarPos2DX(o.Position, o.PositionMax, new Point(x, y), new Point(x, y)))
                {
                    o.OnMove(o);

                    if (mouse == SDL.SDL_BUTTON_LEFT)
                    {
                        o.OnClick(o);
                        o.IsPushed = true;
                    }
                    else
                    {
                        if (o.IsPushed == true)
                            o.OnCloseClick(o);
                        o.IsPushed = false;
                    }
                }
                else
                {
                    if (o.IsDraged == true)
                        o.OnDown(o);
                    o.IsDraged = false;
                    o.IsPushed = false;
                }
            }
        }

        public void Draw()
        {
            DrawebleSolver.ZCounter = 0f;
            for (int i = 0; i < Items.Count; i++)
            {
                __Widget o = Items[i];
                if (!o.IsVisable) continue;
             
                o.Paint(DrawebleSolver);
            }
        }
    }
}
