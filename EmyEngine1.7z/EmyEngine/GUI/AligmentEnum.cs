﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public enum Aligment : uint
    {
      
        Left =      0x00000001,
        Right =     0x00000002,
        Top =       0x00000004,
        Down =      0x00000010,
        Center =    0x00000020,
    }

}
