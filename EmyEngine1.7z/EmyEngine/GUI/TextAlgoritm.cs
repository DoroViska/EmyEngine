﻿using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class TextAlgoritm
    {



        public static int BaseTextRenderOffsetX(string text1, Font font)
        {
            int renderOffsetX = 0;
            int renderOffsetY = 0;

            for (int i = 0; i < text1.Length; i++)
            {

                if (text1[i] == '\n')
                {
                    renderOffsetX = 0;
                    renderOffsetY += 75;
                    continue;
                }

                {
                    RenderChar rnd = font.CharArray[(ushort)text1[i]];            
                    renderOffsetX += rnd.Texture.Width + 5;

                }

            }
            return renderOffsetX;

        }
        public static void BaseTextRender(string text1, Font font)
        {
            if (text1 == null || text1 == string.Empty)
                return;


            int renderOffsetX = 0;
            int renderOffsetY = 0;

            for (int i = 0; i < text1.Length; i++)
            {

                if (text1[i] == '\n')
                {
                    renderOffsetX = 0;
                    renderOffsetY += 75;
                    continue;
                }

                {
                    RenderChar rnd = font.CharArray[(ushort)text1[i]];

                    rnd.Texture.Bind();

                    GL.Begin(PrimitiveType.TriangleStrip);



                    GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(renderOffsetX + 0, renderOffsetY + 0, 0);
                    GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(renderOffsetX + 0, renderOffsetY + rnd.Texture.Height, 0);
                    GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(renderOffsetX + rnd.Texture.Width, renderOffsetY + 0, 0);
                    GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(renderOffsetX + rnd.Texture.Width, renderOffsetY + rnd.Texture.Height, 0);
                    GL.End();

                    rnd.Texture.EndBind();
                    renderOffsetX += rnd.Texture.Width + 5;

                }

            }
        }






    }
}
