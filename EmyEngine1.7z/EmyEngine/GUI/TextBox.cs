﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class TextBox : Widget
    {
        public string Text { set; get; }
        public void AutoSize()
        {
            this.Height = (int)(75f * FontSize);
            this.Width = (int)(((float)TextAlgoritm.BaseTextRenderOffsetX(Text, GameEngine.CurrentFont)) * FontSize + 5f);

        }
        public float FontSize { set; get; } = 0.3f;
        public override void Paint(IDrawebleContextSolver context)
        {
            IGraphics2D gp = context.CreateGraphics();


            gp.Save();
            gp.Move(new Point(0, 1));


            gp.DrawRectangle(this.Position, this.PositionMax, Color.White);

            gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xDC, 0xDC, 0xDC, 0xFF));

          



            gp.LineWidth = 1f;
            gp.Restore();
        }
    }
}
