﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class Label : Widget
    {
        public string Text { set; get; }
        Point addd = new Point(3, 0);

        public float FontSize { set; get; } = 0.3f;
        public Color FontColor { set; get; } = Color.Bytes(0x66, 0x66, 0x66);

        public void AutoSize()
        {
            this.Height = (int)(75f * FontSize);
            this.Width = (int)(((float)TextAlgoritm.BaseTextRenderOffsetX(Text, GameEngine.CurrentFont)) * FontSize + 5f);

        }

        public override void Paint(IDrawebleContextSolver context)
        {
            IGraphics2D gp = context.CreateGraphics();
            gp.LineWidth = 2f;

            gp.DrawText(this.Text, this.Position + addd, Color.Bytes(0x66, 0x66, 0x66), GameEngine.CurrentFont, FontSize);
            gp.LineWidth = 1f;

        }
    }
}
