﻿using EmyEngine.Imaging;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmyEngine.GUI
{
    public class __WidgetСontainer : __Widget
    {



        public List<__Widget> Items { set; get; } = new List<__Widget>();

        public override void Updated(int x, int y, uint mouse)
        {
            __GUIInstance.WindowLoop(Items,  x - (int)this.Position.X,  y - (int)this.Position.Y,  mouse, (int)this.Width, (int)this.Height);
        }

        public override void Resize(int rW, int rH)
        {
           

            bool leftrith = false;
       

            if (((uint)(Anchor & Aligment.Left) == (uint)Aligment.Left) && ((uint)(Anchor & Aligment.Right) == (uint)Aligment.Right))
            {

                this.Width += rW;
                for (int i = 0; i < Items.Count; i++)
                {
                    __Widget o = Items[i];
                    o.Resize(rW, 0);

                }
                if (((uint)(Anchor & Aligment.Down) == (uint)Aligment.Down) && ((uint)(Anchor & Aligment.Top) != (uint)Aligment.Top))
                {
                    SetPositionY ( this.Position.Y + rH);

                }
                leftrith = true;
            }
            if (((uint)(Anchor & Aligment.Top) == (uint)Aligment.Top) && ((uint)(Anchor & Aligment.Down) == (uint)Aligment.Down))
            {

                this.Height += rH;
                for (int i = 0; i < Items.Count; i++)
                {
                    __Widget o = Items[i];
                    o.Resize(0, rH);
                }
                if (((uint)(Anchor & Aligment.Right) == (uint)Aligment.Right) && ((uint)(Anchor & Aligment.Left) != (uint)Aligment.Left))
                {
                    SetPositionX(this.Position.X + rW);

                }
                leftrith = true;
            }

            if (leftrith == true)
                return;
  
            if ((uint)(Anchor & Aligment.Right) == (uint)Aligment.Right)
            {
                SetPositionX(this.Position.X + rW);

            }
            if ((uint)(Anchor & Aligment.Down) == (uint)Aligment.Down)
            {
                SetPositionY( this.Position.Y + rH);

            }

        }

        public override void Paint(IDrawebleContextSolver DrawebleSolver)
        {
            Graphics2D gp = new Graphics2D(DrawebleSolver); 
            GL.PushMatrix();       
            GL.Translate(this.Position.X, this.Position.Y, 0);
            gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0xA2, 0x00, 255));
            gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0x1B, 0x1B, 0xB3, 255));
            for (int i = 0; i < Items.Count; i++)
            {
                __Widget o = Items[i];
                if (o.IsVisable == false) continue;
                o.Paint(DrawebleSolver);
            }
            GL.PopMatrix();
        }
    }
}
