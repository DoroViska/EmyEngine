﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmyEngine.GUI
{
    public unsafe class __WidgetButton : __Widget
    {
        public string Text { set; get; }
        public float FontSize { set; get; } = 1f;
        public __WidgetButton()
        {
        }
        public void AutoSize()
        {
            this.Height = (int)(75f * FontSize);
            this.Width = (int)( ((float)TextAlgoritm.BaseTextRenderOffsetX(Text,GameEngine.CurrentFont)) * FontSize + 5f);

        }
        Point addd = new Point(3,0);
        public override void Paint(IDrawebleContextSolver context)
        {
            Graphics2D gp = new Graphics2D(context);
            
            if (IsPushed == true)
            {
                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0xA2, 0x00, 255));

                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0x1B, 0x1B, 0xB3, 255));

                gp.DrawText(this.Text, this.Position + addd, Color.Black, GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;


                return;
            }


            if (this.IsDraged == true)
            {
                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0xA2, 0x00, 255));

                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0x87, 0x00, 255));

                gp.DrawText(this.Text, this.Position + addd, Color.Black, GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;
            }
            else
            {

                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0x62, 0x00, 255));
           
                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xFF, 0xA2, 0x00, 255));

                gp.DrawText(this.Text, this.Position + addd, Color.Black, GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;
            }


        }
    }
}
