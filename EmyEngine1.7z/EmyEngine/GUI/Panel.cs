﻿using EmyEngine.Imaging;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class Panel : Widget
    {
        public WidgetCollection Items { private set; get; }

        public Panel()
        {
            Items = new WidgetCollection(this);

        }
    
        public override void Paint(IDrawebleContextSolver context)
        {
            IGraphics2D gp = context.CreateGraphics();

            gp.Save();
        
            gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xF6, 0xF6, 0xF6));
            gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Black);
            gp.Move(this.Position);
            for (int i = 0; i < Items.Count; i++)
            {
                Widget o = Items[i];
                if (!o.IsVisable)
                    continue;
                if(GameUI.CursorCollusion(o.Position,o.PositionMax,new Point(0,0),new Point(this.Width,this.Height)))
                    o.Paint(context);
            }
           
            gp.Restore();


        }

        public override void Update(float TimeStep)
        {
            base.Update(TimeStep);
        }
    }
}
