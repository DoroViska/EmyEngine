﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class CheckBox : Widget
    {
        public CheckBox()
        {
            this.Width = 20;
            this.Height = 20;
            this.Click += CheckBox_Click;


        }
        public event UIEventArgs ValueChanged;
        private void CheckBox_Click(object sender, EventArgs e)
        {
            Checked = !Checked;
            if (ValueChanged != null)
                ValueChanged(this,EventArgs.Empty);
        }

        public bool Checked { set; get; } = false;

        public string Text { set; get; }

        public float FontSize { set; get; } = 0.3f;
        public override void Paint(IDrawebleContextSolver context)
        {

            IGraphics2D gp = context.CreateGraphics();


            gp.Save();
            gp.Move(new Point(0, 1));
        

            gp.DrawRectangle(this.Position, this.PositionMax, Color.White);
          
            gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xDC, 0xDC, 0xDC, 0xFF));

            gp.LineWidth = 3f;
            if (Checked == true)
            {
                gp.DrawLine(this.Position + new Point(5, 5), this.PositionMax + new Point(-5, -5), Color.Black);
                gp.DrawLine(this.Position + new Point(this.Width - 5, 5), this.PositionMax - new Point(this.Width - 5, 5), Color.Black);
            }

            gp.DrawText(Text, this.Position + new Point(32,0), Color.Bytes(0x66, 0x66, 0x66, 0xFF), GameEngine.CurrentFont, FontSize);



            gp.LineWidth = 1f;
            gp.Restore();
        }
    }
}
