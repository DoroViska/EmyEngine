﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public struct Point
    {
        public Point(int XY)
        {
            this.X = XY;
            this.Y = XY;
        }
        public Point(int X,int Y)
        {
            this.X = X;
            this.Y = Y;
        }
        public int X;
        public int Y;

        public override bool Equals(Object obj)
        {
            // Performs an equality check on two points (integer pairs).
            if (obj == null || GetType() != obj.GetType()) return false;
            Point p = (Point)obj;
            return (X == p.X) && (Y == p.Y);
        }
        public override int GetHashCode()
        {
            return Tuple.Create(X,Y).GetHashCode();
        }
     
        public static Point operator +(Point a, Point b)
        {
            return new Point(a.X + b.X,a.Y + b.Y);
        }
        public static Point operator -(Point a, Point b)
        {
            return new Point(a.X - b.X, a.Y - b.Y);
        }
        public static Point operator *(Point a, Point b)
        {
            return new Point(a.X * b.X, a.Y * b.Y);
        }
        public static Point operator /(Point a, Point b)
        {
            return new Point(a.X / b.X, a.Y / b.Y);
        }



    }
}
