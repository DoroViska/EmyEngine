﻿using EmyEngine.Imaging;

namespace EmyEngine.GUI
{
    public interface IGraphics2D
    {
        IDrawebleContextSolver CurrentDraweble { get; }
        float LineWidth { get; set; }
        int RenderHegiht { get; }
        int RenderWidth { get; }
        float ZCounter { get; set; }

        void DrawImage(Point pos, BaseBitmap bmp);
        void DrawLine(Point start, Point end, Color color);
        void DrawPoint(Point pos, Color color);
        void DrawRectangle(Point leUp, Point riDown, Color color);
        void DrawSolidRectangle(Point leUp, Point riDown, Color color);
        void DrawSolidTriangle(Point pos1, Point pos2, Point pos3, Color color);
        void DrawText(string text, Point pos, Color color, Font font, float scale_size);
        void DrawTriangle(Point pos1, Point pos2, Point pos3, Color color);
        void Move(Point all_To);
        void Restore();
        void Save();
    }
}