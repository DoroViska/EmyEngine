﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{

    public class Button : Widget
    {
        public string Text { set; get; }
        public float FontSize { set; get; } = 0.3f;
        public Button()
        {
        }
        public void AutoSize()
        {
            this.Height = (int)(75f * FontSize);
            this.Width = (int)(((float)TextAlgoritm.BaseTextRenderOffsetX(Text, GameEngine.CurrentFont)) * FontSize + 5f);

        }
        Point addd = new Point(3, 0);


        public override void Paint(IDrawebleContextSolver context)
        {
            IGraphics2D gp = context.CreateGraphics();
            if (IsPushed == true)
            {
                gp.Save();
                gp.Move(new Point(0,1));
                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xF6, 0xF6, 0xF6, 0xFF));

                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xDC, 0xDC, 0xDC, 0xFF));
                gp.DrawLine(this.Position + new Point(1, 1), this.Position + new Point(1 + this.Width - 2, 1), Color.White);
                gp.DrawText(this.Text, this.Position + addd, Color.Bytes(0x66, 0x66, 0x66), GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;
                gp.Restore();

                return;
            }


            if (this.IsDraged == true)
            {
                gp.Save();
                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.Bytes(0xF6, 0xF6, 0xF6, 0xFF));

                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xDC, 0xDC, 0xDC, 0xFF));
                gp.DrawLine(this.Position + new Point(1,1), this.Position + new Point(1 + this.Width - 2, 1),Color.White);
                gp.DrawText(this.Text, this.Position + addd, Color.Bytes(0x66, 0x66, 0x66), GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;
                gp.Restore();
            }
            else
            {
                gp.Save();
                gp.LineWidth = 1f;
                gp.DrawRectangle(this.Position, this.PositionMax, Color.White);

                gp.DrawSolidRectangle(this.Position, this.PositionMax, Color.Bytes(0xDC, 0xDC, 0xDC,0xFF));

                gp.DrawText(this.Text, this.Position + addd, Color.Bytes(0x66, 0x66, 0x66, 0xFF), GameEngine.CurrentFont, FontSize);
                gp.LineWidth = 1f;
                gp.Restore();
            }
         
        }

        public override void Update(float TimeStep)
        {
            base.Update(TimeStep);
        }
    }
}
