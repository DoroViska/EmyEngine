﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenTK.Graphics.OpenGL;
using EmyEngine.Imaging;

namespace EmyEngine.GUI
{
    public struct Graphics2D : IGraphics2D
    {
        public IDrawebleContextSolver CurrentDraweble { private set; get; }
        public Graphics2D(IDrawebleContextSolver draweble)
        {
            CurrentDraweble = draweble;
        }

        public int RenderWidth { get { return CurrentDraweble.GetWidth(); } }

        public int RenderHegiht { get { return CurrentDraweble.GetHeight(); } }

        public float LineWidth
        {
            set
            {
                if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
                GL.LineWidth(value);
            }
            get
            {
                if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
                float val = 0f;
                GL.GetFloat(GetPName.LineWidth,out val);
                return val;
            }
        }
        public void Move(Point all_To)
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.Translate(all_To.X,all_To.Y,0f);
        }




        public void DrawLine(Point start, Point end, Color color)
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {
                GL.Translate(0f, 0f, ZCounter);
                ZCounter -= 0.01f;
                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                    color.R * Color.FloatFriction, 
                    color.G * Color.FloatFriction,
                    color.B * Color.FloatFriction,
                    color.A * Color.FloatFriction
                    );
                GL.Begin(PrimitiveType.Lines);
                {

                    GL.Vertex2(start.X, start.Y);
                    GL.Vertex2(end.X, end.Y);
                }
                GL.End();
                GL.Color4(1f, 1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
        public void DrawPoint(Point pos, Color color)
        {
         
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {
                GL.Translate(0f, 0f, ZCounter);
                ZCounter -= 0.01f;
                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                   color.R * Color.FloatFriction,
                   color.G * Color.FloatFriction,
                   color.B * Color.FloatFriction,
                   color.A * Color.FloatFriction
                   );
                GL.Begin(PrimitiveType.Points);
                {
                    GL.Vertex2(pos.X, pos.Y);
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
        public void DrawTriangle(Point pos1, Point pos2, Point pos3, Color color)
        {
            GL.Translate(0f, 0f, ZCounter);
            ZCounter -= 0.01f;
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {
                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                   color.R * Color.FloatFriction,
                   color.G * Color.FloatFriction,
                   color.B * Color.FloatFriction,
                   color.A * Color.FloatFriction
                   );
                GL.Begin(PrimitiveType.Triangles);
                {
                    GL.Vertex2(pos1.X, pos1.Y);
                    GL.Vertex2(pos2.X, pos2.Y);              
                    GL.Vertex2(pos3.X, pos3.Y);
            
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
        public void DrawSolidTriangle(Point pos1, Point pos2, Point pos3, Color color)
        {
            GL.Translate(0f, 0f, ZCounter);
            ZCounter -= 0.01f;
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {
                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                   color.R * Color.FloatFriction,
                   color.G * Color.FloatFriction,
                   color.B * Color.FloatFriction,
                   color.A * Color.FloatFriction
                   );
                GL.Begin(PrimitiveType.Triangles);
                {
                    GL.Vertex2(pos1.X, pos1.Y);
                    GL.Vertex2(pos2.X, pos2.Y);
                    GL.Vertex2(pos3.X, pos3.Y);
                    GL.Vertex2(pos1.X, pos1.Y);
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
        public void DrawRectangle(Point leUp,Point riDown, Color color)
        {
            GL.Translate(0f, 0f, ZCounter);
            ZCounter -= 0.01f;
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {

                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                   color.R * Color.FloatFriction,
                   color.G * Color.FloatFriction,
                   color.B * Color.FloatFriction,
                   color.A * Color.FloatFriction
                   );
                GL.Begin(PrimitiveType.Quads);
                {
                    float XL = riDown.X - leUp.X;
                    float YL = riDown.Y - leUp.Y;

                    GL.Vertex2(leUp.X, leUp.Y);

                    GL.Vertex2(leUp.X + XL, leUp.Y);

                    GL.Vertex2(leUp.X + XL, leUp.Y + YL);

                    GL.Vertex2(leUp.X, leUp.Y + YL);

                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
       }
        public void DrawSolidRectangle(Point leUp, Point riDown, Color color)
        {
            GL.Translate(0f, 0f, ZCounter);
            ZCounter -= 0.01f;
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
            {

                GL.Normal3(0f, 0f, 1f);
                GL.Color4(
                   color.R * Color.FloatFriction,
                   color.G * Color.FloatFriction,
                   color.B * Color.FloatFriction,
                   color.A * Color.FloatFriction
                   );
                GL.Begin(PrimitiveType.LineStrip);
                {
                    float XL = riDown.X - leUp.X;
                    float YL = riDown.Y - leUp.Y;

                    GL.Vertex2(leUp.X, leUp.Y);
                    GL.Vertex2(leUp.X + XL, leUp.Y);
                    GL.Vertex2(leUp.X + XL, leUp.Y + YL);
                    GL.Vertex2(leUp.X, leUp.Y + YL);
                    GL.Vertex2(leUp.X, leUp.Y);
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
        public void DrawText(string text,Point pos,Color color, Font font,float scale_size)
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();

            GL.PushMatrix();
            {
                GL.Translate(0f, 0f, ZCounter);
                ZCounter -= 0.01f;
                GL.Normal3(0f,0f,1f);
                GL.Translate(pos.X,pos.Y,0f);
                GL.Scale((float)scale_size, (float)scale_size, (float)scale_size);
                GL.Color4(color.R,color.G,color.B, color.A);

                TextAlgoritm.BaseTextRender(text,font);

                GL.Color4(1f,1f,1f,1f);
            }
            GL.PopMatrix();

        }
        public void DrawImage(Point pos, BaseBitmap bmp)
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();

            GL.PushMatrix();
            {
                GL.Translate(0f, 0f, ZCounter);
                ZCounter -= 0.01f;
                GL.Normal3(0f, 0f, 1f);
                GL.Translate(pos.X, pos.Y, 0f);
            
               

                GL.Begin(PrimitiveType.Points);
                {
                    for (int w = 0; w < bmp.Width; w++)
                    {
                        for (int h = 0; h < bmp.Height; h++)
                        {
                            Color c = bmp.ColorMap[w,h];
                            GL.Color4(c.R, c.G, c.B, c.A);
                            GL.Vertex2(w,h);
                        }
                    }
                }              
                GL.Color4(1f, 1f, 1f, 1f);
            }
            GL.PopMatrix();

        }

        public void Save()
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PushMatrix();
        }
        public void Restore()
        {
            if (!CurrentDraweble.IsDraweble()) throw new CurrentGraphicsIsNotDrawebleException();
            GL.PopMatrix();
        }

        public float ZCounter { set { CurrentDraweble.ZCounter = value; } get { return CurrentDraweble.ZCounter; } }

  


    }
}
