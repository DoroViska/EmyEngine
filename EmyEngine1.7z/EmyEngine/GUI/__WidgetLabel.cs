﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmyEngine.GUI
{
    unsafe class __WidgetLabel : __Widget
    {


        public string Text { private set; get; }
        Point addd = new Point(3, 0);
        public float FontSize { set; get; } = 1f;
        public Color FontColor { set; get; } = Color.Black;
        public void AutoSize()
        {
            this.Height = (int)(75f * FontSize);
            this.Width = (int)(((float)TextAlgoritm.BaseTextRenderOffsetX(Text, GameEngine.CurrentFont)) * FontSize + 5f);

        }

        public override void Paint(IDrawebleContextSolver context)
        {
            Graphics2D gp = new Graphics2D(context);
            gp.LineWidth = 2f;

            gp.DrawText(this.Text, this.Position + addd, FontColor, GameEngine.CurrentFont, FontSize);
            gp.LineWidth = 1f;

        }
    }
}
