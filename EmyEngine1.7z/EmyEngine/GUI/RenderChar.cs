﻿using EmyEngine.Imaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    public class RenderChar
    {
        public RenderChar(Texture2D Texture, ushort Code)
        {
            this.Code = Code;
            this.Texture = Texture;
        }
        public Texture2D Texture { private set; get; }
        public ushort Code { private set; get; }
    }
}
