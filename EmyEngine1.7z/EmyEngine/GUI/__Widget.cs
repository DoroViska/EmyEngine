﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmyEngine.GUI
{

    public delegate void __GUIEvent(__Widget sender);



    public class __Widget
    {


        
        public Aligment Anchor { set; get; } = Aligment.Left | Aligment.Top;

        public virtual void Resize(int rW,int rH)
        {

            bool rithout = false;
            if (((uint)(Anchor & Aligment.Left) == (uint)Aligment.Left) && ((uint)(Anchor & Aligment.Right) == (uint)Aligment.Right))
            {

                this.Width += rW;
                rithout = true;
            }
            if (((uint)(Anchor & Aligment.Top) == (uint)Aligment.Top) && ((uint)(Anchor & Aligment.Down) == (uint)Aligment.Down))
            {

                this.Height += rH;
                rithout = true;
            }
            if (rithout == true)
                return;

            if ((uint)(Anchor & Aligment.Right) == (uint)Aligment.Right)
            {
                SetPositionX( this.Position.X + rW);

            }
            if ((uint)(Anchor & Aligment.Down) == (uint)Aligment.Down)
            {
                SetPositionY( this.Position.Y + rH);

            }
        }

        public virtual void Updated(int x, int y, uint mouse){}

        public __Widget()
        {
            IsPushed = false;
            IsDraged = false;
        }


        public bool IsDraged { set; get; }
        public bool IsPushed { set; get; }
        public bool IsVisable { set; get; } = true;

        public event __GUIEvent Click;
        public virtual void OnClick(__Widget sender)
        {        
            if (IsPushed == false)
            {
                //Console.WriteLine("Push");
                if (Click != null)
                    Click(sender);
                IsPushed = true;
            }
        }


        public event __GUIEvent CloseClick;
        public virtual void OnCloseClick(__Widget sender)
        {
          
                if (CloseClick != null)
                    CloseClick(sender);
             
            
        }

        public event __GUIEvent Move;
        public virtual void OnMove(__Widget sender)
        {

            if (IsDraged == false)
            {
  
                if (Move != null)
                    Move(sender);   
                 IsDraged = true;
            }
                   
        }
        public event __GUIEvent Down;
        public virtual void OnDown(__Widget sender)
        {
          
                if (Down != null)
                    Down(sender);
         
        }

        public string Name { set; get; }
        public bool Focusated { set; get; }

        public void SetPositionX(int v)
        {
            this.Position = new Point(v,this.Position.Y);
        }
        public void SetPositionY(int v)
        {
            this.Position = new Point(this.Position.X,v);
        }



        public Point Position { set; get; }
        public Point PositionMax
        {
            get
            {
                return  new Point(this.Position.X + Width,this.Position.Y + Height);
            }
        }
        public int Width { set; get; }
        public int Height { set; get; }

        public virtual void Paint(IDrawebleContextSolver DrawebleSolver)
        {



        }

        

    }
}
