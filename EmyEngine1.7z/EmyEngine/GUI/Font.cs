﻿using EmyEngine.Imaging;
using EmyEngine.ResourceManagment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.GUI
{
    /// <summary>
    /// Обычный класс UTF16 шрифта
    /// </summary>
    public class Font
    {
        public Font(Resources char_ress,string chars_path)
        {
            CharArray  = new RenderChar[ushort.MaxValue];

            foreach (Resource paten in char_ress.GetResources(chars_path))
            {
           
                ushort Code = Convert.ToUInt16(paten.Name.Replace(".png", ""));
                BaseBitmap b = new BaseBitmap(paten.GetStream());
                b.Replace(Color.Bytes(255, 255, 255, 0), Color.Bytes(0, 0, 0, 0));
                b.Replace(Color.Bytes(0, 0, 0, 255), Color.Bytes(255, 255, 255, 255));
                Texture2D Texture = new Texture2D(b, false);
                RenderChar nchr = new RenderChar(Texture, Code);
                CharArray[nchr.Code]=nchr;
            }


             
        }

        public RenderChar[] CharArray { private set; get; } 

    }
}
