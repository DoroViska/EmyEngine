﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Jitter;
using Jitter.Dynamics;
using Jitter.Collision;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;

using OpenTK.Graphics.OpenGL;
using OpenTK.Graphics;

using EmyEngine;
using EmyEngine.SDL2;
using EmyEngine.Primitivs3D;



namespace EmyEngine
{

   

    public class DDraweble : IDebugDrawable
    {
        public void DebugDraw(IDebugDrawer drawer)
        {
            throw new __std_badOpCode_fromatException();
        }
    }

    public class DebugDrawer : IDebugDrawer
    {
        

        public void DrawLine(JVector start, JVector end)
        {
            GL.PushMatrix();
            {
                GL.Color3(1f,0f,0f);
                GL.Begin(PrimitiveType.Lines);
                {

                    GL.Vertex3(start.X, start.Y, start.Z);
                    GL.Vertex3(end.X, end.Y, end.Z);
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }

        public void DrawPoint(JVector pos)
        {
            GL.PushMatrix();
            {
                GL.Color3(1f, 0f, 0f);
                GL.Begin(PrimitiveType.Points);
                {
                    GL.Vertex3(pos.X,pos.Y,pos.Z);
                }
                GL.End();
                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }

        public void DrawTriangle(JVector pos1, JVector pos2, JVector pos3)
        {
            GL.PushMatrix();
            {
                GL.Color3(1f, 0f, 0f);
                GL.Begin(PrimitiveType.Lines);
                {
                    GL.Vertex3(pos1.X, pos1.Y, pos1.Z);
                    GL.Vertex3(pos2.X, pos2.Y, pos2.Z);

                    GL.Vertex3(pos2.X, pos2.Y, pos2.Z);
                    GL.Vertex3(pos3.X, pos3.Y, pos3.Z);

                    GL.Vertex3(pos3.X, pos3.Y, pos3.Z);
                    GL.Vertex3(pos1.X, pos1.Y, pos1.Z);
         
                }
                GL.End();

                GL.Color3(1f, 1f, 1f);
            }
            GL.PopMatrix();
        }
    }
}
