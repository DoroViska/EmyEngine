﻿using EmyEngine.Gameing;
using EmyEngine.Imaging;
using EmyEngine.Models3D;
using Jitter.Collision.Shapes;
using Jitter.LinearMath;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.Terrain
{

  

    public class UnWrapTerrain : GameObject
    {


        public float[,] Map;


     
        public UnWrapTerrain(BaseBitmap mp)
        {
            //TextureMap = mp;

            Map = new float[mp.ColorMap.GetLength(0), mp.ColorMap.GetLength(1)];
            for (int i = 0; i < mp.ColorMap.GetLength(0) - 1; i++)
            {
                for (int j = 0; j < mp.ColorMap.GetLength(1) - 1; j++)
                {
                    Map[i, j] = (float)mp.ColorMap[i, j].R * 0.1f;
                }
            }



            this.Body = new ObjectivBody(this, new TerrainShape(Map, 1f,1f));
            this.Body.IsStatic = true;
            this.Body.Position = new JVector(-50f, -80f, -50f);


        }





        public Model3D Model { private set; get; }

        public override void Draw()
        {
            GL.PushMatrix();
            Transformator.SetTransform(Body.Position,Body.Orientation);
            GL.Begin(PrimitiveType.Triangles);

            for (int i = 0;i < Map.GetLength(0) - 1; i++)
            {
                for (int j = 0; j < Map.GetLength(1) - 1; j++)
                {
                    JVector n = Transformator.TriangleNormal(
                        new JVector(i, Map[i, j], j),
                        new JVector(i + 1f, Map[i + 1, j], j),
                        new JVector(i, Map[i, j + 1], j + 1f)
                        );
                    GL.Normal3(n.X,n.Y,n.Z);
                    GL.Vertex3(i, Map[i, j],    j);
                    GL.Vertex3(i + 1f, Map[i + 1, j],    j);
                    GL.Vertex3(i, Map[i, j + 1],    j + 1f);

                    JVector n1 = Transformator.TriangleNormal(
                        new JVector(i + 1f, Map[i + 1, j], j),
                        new JVector(i, Map[i, j + 1], j + 1f), 
                        new JVector(i + 1f, Map[i + 1, j + 1], j + 1f));
                    GL.Normal3(n1.X, n1.Y, n1.Z);
                    GL.Vertex3(i + 1f, Map[i + 1, j], j);
                    GL.Vertex3(i , Map[i, j + 1], j + 1f);
                    GL.Vertex3(i + 1f, Map[i + 1, j + 1], j + 1f);
                }
            }


            GL.End();
            GL.PopMatrix();
        }

        public override void Update()
        {
          
        }
    }
}
