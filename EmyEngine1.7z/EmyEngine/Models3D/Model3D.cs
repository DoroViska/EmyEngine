﻿using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.Models3D
{
    /// <summary>
    /// Базовый класс для моделей
    /// </summary>
    public abstract class Model3D
    {
        public override int GetHashCode()
        {
            return CallList.GetHashCode() ^ Name.GetHashCode();
        }
        public override bool Equals(object obj)
        {
            if (obj == null && !(obj is Model3D))
                return false;
            if (((Model3D)obj).Name == this.Name && ((Model3D)obj).CallList == this.CallList)
                return true;
            else
                return false;
        }



        public string Name { protected set; get; }

        /// <summary>
        /// ID модели
        /// </summary>
        public int CallList { private set; get; }

        /// <summary>
        /// Сообщяет о том что нужно создать модель в памяти видеокарты
        /// </summary>
        /// <param name="name"></param>
        public void Create(string name)
        {
            this.Name = name;
            CallList = GL.GenLists(1);
            GL.NewList(CallList, ListMode.Compile);
            this.OnDraw();
            GL.EndList();
        }

        /// <summary>
        /// Функция отрисовки модели
        /// </summary>
        public abstract void OnDraw();


        /// <summary>
        /// Вызывает модель для отрисовки
        /// </summary>
        public void Draw()
        {
            GL.CallList(CallList);            
        }


    }



}
