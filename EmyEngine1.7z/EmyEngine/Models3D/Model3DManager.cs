﻿using EmyEngine.ResourceManagment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmyEngine.Models3D
{
    public class Model3DManager
    {
        public Model3DManager()
        {
            this.Models = new List<Model3D>();
        }


        public Model3DManager(Resources r)
        {
            this.Models = new List<Model3D>();

            foreach (Resource res in r.GetResources())
            {
               if(res.Path.Length - 10 >= 0)
                    if (res.Path.Remove(0, res.Path.Length - 10) == "/model.xml")
                    {
                        XMLModel md = new XMLModel();
                        md.LoadFromResources(r, res.Path.Remove(res.Path.Length - 10, 10));

                        this.Models.Add(md);

                        Console.WriteLine("[Model loaded]: " + res.Path.Remove(res.Path.Length - 10, 10));
                    }
                   
            }
        }




        private List<Model3D> Models;
       



        







        public void AddModel(Model3D model)
        {
            Models.Add(model);
        }



        public void RemoveModel(Model3D model)
        {
            Models.Remove(model);
        }


        public Model3D GetModel(string name)
        {
            for (int i = 0;i < Models.Count;i++)
            {
                if (Models[i].Name == name) {
                    return Models[i];
                  
                }

                //Console.WriteLine(":" + Models[i].Name +":" + name + ":");
            }
            throw new Model3DNotFoundException(name);

        }

    }
}
