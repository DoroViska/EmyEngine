﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

using Jitter.Collision.Shapes;
using Jitter;
using Jitter.LinearMath;

using EmyEngine;

using EmyEngine.Imaging;
using EmyEngine.Primitivs3D;

using OpenTK.Input;
using OpenTK.Graphics.OpenGL;
using EmyEngine.Gameing;
using EmyEngine.ResourceManagment;

namespace EmyEngine.Models3D
{
    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public struct Face
    {

        public static Face Vector(JVector a, JVector b, JVector c)
        {
            Face z;
            z.A = a;
            z.B = b;
            z.C = c;
            return z;
        }

        public static Face Zero()
        {
            Face z;
            z.A = JVector.Zero;
            z.B = JVector.Zero;
            z.C = JVector.Zero;
            return z;
        }

        public JVector Normal()
        {
            float x1 = this.A.X;
            float x2 = this.B.X;
            float x3 = this.C.X;
            float y1 = this.A.Y;
            float y2 = this.B.Y;
            float y3 = this.C.Y;
            float z1 = this.A.Z;
            float z2 = this.B.Z;
            float z3 = this.C.Z;
            JVector vec = JVector.Zero;
            vec.X = (y2 - y1) * (z3 - z1) - (y3 - y1) * (z2 - z1);
            vec.Y = (z2 - z1) * (x3 - x1) - (z3 - z1) * (x2 - x1);
            vec.Z = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
            return vec;
        }


        public JVector A;
        public JVector B;
        public JVector C;
        public JVector this[int s]
        {
            set
            {
                if (s == 0)
                    A = value;
                if (s == 1)
                    B = value;
                if (s == 2)
                    C = value;
            }
            get
            {
                if (s == 0)
                    return A;
                if (s == 1)
                    return B;
                if (s == 2)
                    return C;
                return JVector.Zero;
            }
        }
    }



    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public class ModelSubObject
    {
        public int TextureId = -1;
        public bool NeedTexture
        {
            get
            {
                if (TextureId < 0)
                    return false;
                return true;
            }
        }

        public List<Face> Faces;
        public List<Face> TFaces;

    }


    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public class TextureObject
    {
        public string TextureName;
        public uint NativeHandle;
    }


    [Serializable]
    [StructLayout(LayoutKind.Sequential)]
    public class FlatModel
    {
        public List<ModelSubObject> SubObjects;
        public List<TextureObject> Textures;
    }







    public class XMLModel : Model3D
    {
        FlatModel flat;

        Resources fsr;
        string fsr_dir;
        public void LoadFromResources(Resources fsri,string dir)
        {
            fsr = fsri;
            fsr_dir = dir;
            XmlSerializer sr = new XmlSerializer(typeof(FlatModel));
            flat = (FlatModel)sr.Deserialize(fsr.GetResource(dir + "/model.xml").GetStream());
            this.Name = dir;
            this.Create(dir);
        }

        List<Texture2D> Texters = new List<Texture2D>();

        public override void OnDraw()
        {

            GL.Scale(0.05f, 0.05f, 0.05f);
            foreach (TextureObject sb in flat.Textures)
            {
                
                Texture2D ds = new Texture2D( new BaseBitmap(fsr.GetResource(fsr_dir + "/" + sb.TextureName).GetStream()));
                Console.WriteLine(fsr.GetResource(fsr_dir + "/" + sb.TextureName).GetStream().ReadByte());
                sb.NativeHandle = ds.Texture;
                Texters.Add(ds);
            }

            foreach (ModelSubObject sb in flat.SubObjects)
            {

                if (sb.NeedTexture)
                {
                    GL.Enable(EnableCap.Texture2D);
                    GL.BindTexture(TextureTarget.Texture2D, flat.Textures[sb.TextureId].NativeHandle);
                }

                GL.Enable(EnableCap.Normalize);
                GL.Begin(PrimitiveType.Triangles);
   

                for (int i = 0;i < sb.Faces.Count;i++)
                {


                    JVector nor = sb.Faces[i].Normal();
                    GL.Normal3(nor.X, nor.Y, nor.Z);

                    if (sb.NeedTexture && sb.TFaces.Count != 0)
                    {
                        GL.TexCoord2(sb.TFaces[i].A.X, sb.TFaces[i].A.Y);
                        GL.Vertex3(sb.Faces[i].A.X, sb.Faces[i].A.Y, sb.Faces[i].A.Z);

                        GL.TexCoord2(sb.TFaces[i].B.X, sb.TFaces[i].B.Y);
                        GL.Vertex3(sb.Faces[i].B.X, sb.Faces[i].B.Y, sb.Faces[i].B.Z);

                        GL.TexCoord2(sb.TFaces[i].C.X, sb.TFaces[i].C.Y);
                        GL.Vertex3(sb.Faces[i].C.X, sb.Faces[i].C.Y, sb.Faces[i].C.Z);
                    }
                    else
                    {
                        GL.Vertex3(sb.Faces[i].A.X, sb.Faces[i].A.Y, sb.Faces[i].A.Z);
                        GL.Vertex3(sb.Faces[i].B.X, sb.Faces[i].B.Y, sb.Faces[i].B.Z);
                        GL.Vertex3(sb.Faces[i].C.X, sb.Faces[i].C.Y, sb.Faces[i].C.Z);

                    }
                }
                GL.End();
                GL.Disable(EnableCap.Normalize);
                GL.Disable(EnableCap.Texture2D);

            }
                       
        }

    }
}
