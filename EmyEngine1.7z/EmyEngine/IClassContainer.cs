﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace EmyEngine
{

    public delegate void BaseDelegate(object sender,object argv);

    public interface IFormateble
    {
        object FormatTo(IClassContainer cntr);
    }
    public interface IFormatebleReadeble
    {
        object FormatRead(IClassContainer cntr);
    }


    public interface IClassContainer
    {
        string GetName();
        void SetName(string PolyName);
        void Push(BaseDelegate data);
        void Push(IClassContainer data);
        void Push(IClassContainer[] data);
        void Push(string data);
        void Push(int data);
        void Push(float data);
        void Push(long data);
        void Push(double data);
        void Push(short data);
        void Push(byte data);
        void Push(Stream data);
        void Push(BaseDelegate[] data);
        void Push(string[] data);
        void Push(int[] data);
        void Push(short[] data);
        void Push(byte[] data);
        void Push(float[] data);
        void Push(long[] data);
        void Push(double[] data);
        void Push(Stream[] data);
        void XClose();

    }
}
